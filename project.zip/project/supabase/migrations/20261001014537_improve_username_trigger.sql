/*
# Improve auto-generated username format

The trigger that creates profiles on signup was generating usernames like "reader@example.com_abc123".
Updated to use just the part before the @ symbol, without the UUID suffix, for cleaner usernames.
If the username is already taken, it appends a short numeric suffix.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  base_username text;
  final_username text;
  suffix int := 0;
BEGIN
  base_username := COALESCE(split_part(NEW.email, '@', 1), 'reader');
  final_username := base_username;

  WHILE EXISTS (SELECT 1 FROM profiles WHERE username = final_username) LOOP
    suffix := suffix + 1;
    final_username := base_username || suffix::text;
  END LOOP;

  INSERT INTO profiles (id, username, display_name)
  VALUES (
    NEW.id,
    final_username,
    COALESCE(split_part(NEW.email, '@', 1), 'New Reader')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;
