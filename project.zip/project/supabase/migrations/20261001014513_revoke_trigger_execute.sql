/*
# Revoke public execute on trigger function

The handle_new_user() function is a trigger that auto-creates a profile on signup.
It should not be callable directly via the REST API. Revoke EXECUTE from anon and authenticated.
*/

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;
