/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        charcoal: {
          DEFAULT: '#0F1115',
          50: '#1C1F26',
          100: '#171A21',
          200: '#121419',
          300: '#0F1115',
        },
        cream: {
          DEFAULT: '#F5EFE6',
          50: '#FBF8F2',
          100: '#F5EFE6',
          200: '#E8DFD2',
          300: '#D6CBB8',
        },
        rose: {
          DEFAULT: '#B67C8A',
          50: '#E8C9CF',
          100: '#D9A8B0',
          200: '#C9949C',
          300: '#B67C8A',
          400: '#9A6470',
          500: '#7E4F5A',
        },
        gold: {
          DEFAULT: '#D4A95A',
          50: '#F0DCA8',
          100: '#E3C582',
          200: '#D4A95A',
          300: '#B8923F',
          400: '#947532',
        },
      },
      fontFamily: {
        serif: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        'scale-in': 'scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        'glow-pulse': 'glowPulse 3s ease-in-out infinite',
        'shimmer': 'shimmer 2.5s linear infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 40px -10px rgba(212, 169, 90, 0.35)' },
          '50%': { boxShadow: '0 0 60px -5px rgba(212, 169, 90, 0.55)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    },
  },
  plugins: [],
};
