import { useState, useEffect, useCallback, useRef } from 'react';
import { audioEngine, type AudioTrack } from '@/lib/audioEngine';

export function useAudioEngine() {
  const [, forceRender] = useState(0);
  const cbRef = useRef<() => void>(() => {});

  cbRef.current = () => forceRender((n) => n + 1);

  useEffect(() => {
    audioEngine.setOnStateChange(() => cbRef.current());
    return () => {
      audioEngine.setOnStateChange(() => {});
    };
  }, []);

  const playTrack = useCallback((track: AudioTrack) => {
    audioEngine.playTrack(track);
  }, []);

  const stop = useCallback(() => {
    audioEngine.stop();
  }, []);

  const preload = useCallback((url: string) => {
    audioEngine.preload(url);
  }, []);

  const toggleMute = useCallback(() => {
    audioEngine.setMuted(!audioEngine.isMuted());
    forceRender((n) => n + 1);
  }, []);

  const togglePlayPause = useCallback(() => {
    if (audioEngine.isPlaying()) {
      audioEngine.pause();
    } else {
      audioEngine.resume();
    }
  }, []);

  const unlock = useCallback(() => {
    audioEngine.unlock();
  }, []);

  return {
    playTrack,
    stop,
    preload,
    toggleMute,
    togglePlayPause,
    unlock,
    isMuted: audioEngine.isMuted(),
    isPlaying: audioEngine.isPlaying(),
    isUserPaused: audioEngine.isUserPaused(),
    isAudioUnlocked: audioEngine.isAudioUnlocked(),
    hasPendingTrack: audioEngine.hasPendingTrack(),
    hasLoadError: audioEngine.hasLoadError(),
    currentTitle: audioEngine.getCurrentTitle(),
    currentUrl: audioEngine.getCurrentUrl(),
    currentTime: audioEngine.getCurrentTime(),
    isAudioPaused: audioEngine.isAudioPaused(),
  };
}
