import { useState, useEffect } from 'react';

export interface FetchedBook {
  coverUrl: string;
  synopsis?: string;
  averageRating?: number;
  ratingsCount?: number;
}

export const PLACEHOLDER_COVER =
  'data:image/svg+xml,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300" viewBox="0 0 200 300">
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#1C1F26"/>
          <stop offset="100%" stop-color="#0F1115"/>
        </linearGradient>
      </defs>
      <rect width="200" height="300" fill="url(#g)"/>
      <text x="100" y="145" text-anchor="middle" font-family="Georgia, serif" font-size="13" fill="#D4A95A" opacity="0.7">No Cover</text>
      <text x="100" y="165" text-anchor="middle" font-family="Georgia, serif" font-size="11" fill="#F5EFE6" opacity="0.3">Page Nine</text>
    </svg>`
  );

interface GoogleBook {
  id: string;
  volumeInfo: {
    title: string;
    authors?: string[];
    imageLinks?: {
      thumbnail?: string;
      large?: string;
      medium?: string;
      smallThumbnail?: string;
    };
    averageRating?: number;
    ratingsCount?: number;
    description?: string;
  };
}

interface OpenLibraryDoc {
  cover_i?: number;
  key?: string;
  first_publish_year?: number;
  author_name?: string[];
  title?: string;
}

interface OpenLibraryWork {
  description?: string | { value: string };
  covers?: number[];
  subjects?: string[];
}

interface OpenLibraryRatings {
  summary?: {
    average?: number;
    count?: number;
  };
}

const cache = new Map<string, FetchedBook | null>();

function httpsify(url: string): string {
  return url.replace(/^http:\/\//, 'https://').replace('&edge=curl', '');
}

function pickBestGoogleImage(links: NonNullable<GoogleBook['volumeInfo']['imageLinks']>): string | null {
  const candidates = [
    links.thumbnail,
    links.large,
    links.medium,
    links.smallThumbnail,
  ].filter(Boolean) as string[];

  if (candidates.length === 0) return null;
  return httpsify(candidates[0]);
}

function extractDescription(desc: OpenLibraryWork['description']): string | undefined {
  if (!desc) return undefined;
  if (typeof desc === 'string') return desc;
  return desc.value;
}

async function fetchFromOpenLibrary(query: string): Promise<{ coverUrl?: string; workKey?: string; synopsis?: string; averageRating?: number; ratingsCount?: number } | null> {
  try {
    const res = await fetch(
      `https://openlibrary.org/search.json?title=${encodeURIComponent(query)}&limit=1`
    );
    const data = await res.json();
    const doc = data.docs?.[0] as OpenLibraryDoc | undefined;
    if (!doc) return null;

    const result: { coverUrl?: string; workKey?: string; synopsis?: string; averageRating?: number; ratingsCount?: number } = {};

    if (doc.cover_i) {
      result.coverUrl = `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg`;
    }

    if (doc.key) {
      result.workKey = doc.key;
      try {
        const workRes = await fetch(`https://openlibrary.org${doc.key}.json`);
        const work = (await workRes.json()) as OpenLibraryWork;
        result.synopsis = extractDescription(work.description);
        if (!result.coverUrl && work.covers?.[0]) {
          result.coverUrl = `https://covers.openlibrary.org/b/id/${work.covers[0]}-L.jpg`;
        }
      } catch {
        // work fetch failed — continue without synopsis
      }
      try {
        const ratingsRes = await fetch(`https://openlibrary.org${doc.key}/ratings.json`);
        if (ratingsRes.ok) {
          const ratings = (await ratingsRes.json()) as OpenLibraryRatings;
          if (ratings.summary?.average != null && ratings.summary.average > 0) {
            result.averageRating = ratings.summary.average;
            result.ratingsCount = ratings.summary.count;
          }
        }
      } catch {
        // ratings fetch failed — continue without rating
      }
    }

    return result;
  } catch {
    return null;
  }
}

async function fetchFromGoogleBooks(query: string): Promise<FetchedBook | null> {
  try {
    const res = await fetch(
      `https://www.googleapis.com/books/v1/volumes?q=intitle:${encodeURIComponent(query)}&maxResults=1`
    );
    if (!res.ok) return null;
    const data = await res.json();
    const item = data.totalItems > 0 ? (data.items[0] as GoogleBook) : null;
    if (!item?.volumeInfo) return null;

    const coverUrl = item.volumeInfo.imageLinks
      ? pickBestGoogleImage(item.volumeInfo.imageLinks)
      : null;

    return {
      coverUrl: coverUrl || '',
      synopsis: item.volumeInfo.description,
      averageRating: item.volumeInfo.averageRating,
      ratingsCount: item.volumeInfo.ratingsCount,
    };
  } catch {
    return null;
  }
}

export function useGoogleBookCover(query: string, fallbackCover: string) {
  const [result, setResult] = useState<FetchedBook>({
    coverUrl: fallbackCover || PLACEHOLDER_COVER,
    synopsis: undefined,
    averageRating: undefined,
  });

  useEffect(() => {
    let cancelled = false;
    const key = query;

    if (cache.has(key)) {
      const cached = cache.get(key);
      if (cached) {
        setResult(cached);
      } else {
        setResult({ coverUrl: fallbackCover || PLACEHOLDER_COVER });
      }
      return;
    }

    setResult({ coverUrl: fallbackCover || PLACEHOLDER_COVER, synopsis: undefined, averageRating: undefined });

    const doFetch = async () => {
      // Fetch from OpenLibrary (cover + synopsis from works API) and Google Books (rating) in parallel
      const [olResult, gbResult] = await Promise.all([
        fetchFromOpenLibrary(query),
        fetchFromGoogleBooks(query),
      ]);

      if (cancelled) return;

      const coverUrl = olResult?.coverUrl || gbResult?.coverUrl || fallbackCover || PLACEHOLDER_COVER;
      // Prefer OpenLibrary synopsis, fall back to Google Books
      const synopsis = olResult?.synopsis || gbResult?.synopsis;
      // Prefer OpenLibrary rating, fall back to Google Books
      const averageRating = olResult?.averageRating ?? gbResult?.averageRating;
      const ratingsCount = olResult?.ratingsCount ?? gbResult?.ratingsCount;

      const merged: FetchedBook = {
        coverUrl,
        synopsis,
        averageRating,
        ratingsCount,
      };

      cache.set(key, merged);
      setResult(merged);
    };

    doFetch();
    return () => {
      cancelled = true;
    };
  }, [query, fallbackCover]);

  return result;
}
