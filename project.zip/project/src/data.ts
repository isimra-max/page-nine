export type PostType = 'quote' | 'review';
export type AudioSource = 'library' | 'upload';

export interface Book {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  synopsis: string;
  averageRating: number;
}

export interface Post {
  id: string;
  type: PostType;
  bookId: string;
  text: string;
  username: string;
  rating?: number; // 1-5, only for reviews
  songTitle: string;
  audioUrl?: string;
  audioSource?: AudioSource;
  audioTrimStart?: number;
  audioTrimEnd?: number;
  likes: number;
  liked: boolean;
  saved: boolean;
  comments: Comment[];
  createdAt: string;
}

export interface LibraryTrack {
  id: string;
  title: string;
  url: string;
}

export interface Comment {
  id: string;
  username: string;
  text: string;
}

export const BOOKS: Book[] = [
  {
    id: 'b1',
    title: 'The Midnight Library',
    author: 'Matt Haig',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1604196385i/53345172.jpg',
    synopsis:
      'Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived. Would you have done anything different, if you had the chance to undo your regrets?',
    averageRating: 4.2,
  },
  {
    id: 'b2',
    title: 'Normal People',
    author: 'Sally Rooney',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1539306029i/40665432.jpg',
    synopsis:
      'Connell and Marianne grow up in the same small town in the west of Ireland. In school, he is popular and well-liked, while she is lonely and private. The two develop a strange, intense bond that endures through university years and beyond.',
    averageRating: 4.1,
  },
  {
    id: 'b3',
    title: 'A Little Life',
    author: 'Hanya Yanagihara',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1442347623i/22822858.jpg',
    synopsis:
      'A masterful depiction of heartbreak, and a dark and haunting examination of the limits of human endurance. The story of four college friends over three decades, centered on Jude, a man whose past holds a trauma so profound it threatens to undo every life he touches.',
    averageRating: 4.5,
  },
  {
    id: 'b4',
    title: 'The Secret History',
    author: 'Donna Tartt',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1575066327i/29044.jpg',
    synopsis:
      'A group of clever, eccentric misfits at an elite New England college discover a way of thinking and living that is a world away from the humdrum existence of their contemporaries. But their way of life leads them into a darkness from which they cannot return.',
    averageRating: 4.3,
  },
  {
    id: 'b5',
    title: 'Tomorrow, and Tomorrow, and Tomorrow',
    author: 'Gabrielle Zevin',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1636978687i/60674462.jpg',
    synopsis:
      'On a bitter-cold day, two childhood friends are reunited by chance and become creative partners, building games together. Over thirty years, their success brings them fortune and fame, but also betrayal, tragedy, and love.',
    averageRating: 4.4,
  },
  {
    id: 'b6',
    title: 'Pachinko',
    author: 'Min Jin Lee',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1487339233i/32098831.jpg',
    synopsis:
      'A sweeping saga of four generations of a Korean family who eventually migrate to Japan, following their struggles with identity, belonging, and survival across the turbulent twentieth century.',
    averageRating: 4.5,
  },
  {
    id: 'b7',
    title: 'The Goldfinch',
    author: 'Donna Tartt',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1367451680i/17335004.jpg',
    synopsis:
      'A boy survives a terrorist bombing at a New York museum that kills his mother. In the smoke and chaos, he takes a small Dutch painting called The Goldfinch, and his life is forever entwined with the haunting, luminous artwork.',
    averageRating: 4.1,
  },
  {
    id: 'b8',
    title: 'Conversations with Friends',
    author: 'Sally Rooney',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1497027861i/32242025.jpg',
    synopsis:
      'A college student and aspiring writer in Dublin becomes entangled with an older married couple, navigating desire, friendship, and the complicated terrain of intimacy and power.',
    averageRating: 3.9,
  },
  {
    id: 'b9',
    title: 'My Year of Rest and Relaxation',
    author: 'Ottessa Moshfegh',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1524091919i/37691285.jpg',
    synopsis:
      'A young woman in New York City decides to spend a year in near-total sleep, aided by a pharmacopeia of prescription drugs, in an attempt to reset her life and confront the emptiness at its center.',
    averageRating: 3.8,
  },
  {
    id: 'b10',
    title: 'Circe',
    author: 'Madeline Miller',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1518321830i/35642868.jpg',
    synopsis:
      'In the house of Helios, god of the sun, a daughter is born. But Circe is strange — not powerful like her father, nor viciously alluring like her mother. She turns to witchcraft, and the gods fear what she may become.',
    averageRating: 4.3,
  },
  {
    id: 'b11',
    title: 'The Seven Husbands of Evelyn Hugo',
    author: 'Taylor Jenkins Reid',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1496981000i/34601932.jpg',
    synopsis:
      'Aging Hollywood icon Evelyn Hugo finally decides to give the interview of her life — to an unknown magazine reporter. Over the course of the interview, Evelyn reveals the truth about her seven marriages, and the love she could never publicly claim.',
    averageRating: 4.5,
  },
  {
    id: 'b12',
    title: 'Where the Crawdads Sing',
    author: 'Delia Owens',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1522539527i/36744552.jpg',
    synopsis:
      'For years, rumors of the "Marsh Girl" have haunted Barkley Cove. Kya Clark is barefoot and wild, unfit for polite society. But when a local young man is found dead, she becomes the prime suspect.',
    averageRating: 4.2,
  },
  {
    id: 'b13',
    title: 'The Song of Achilles',
    author: 'Madeline Miller',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1387239072i/13830902.jpg',
    synopsis:
      'Greece in the age of heroes. Patroclus, an awkward young prince, is exiled to the kingdom of Phthia and raised alongside the golden son of a goddess, Achilles. Their bond deepens into something the world will not accept.',
    averageRating: 4.4,
  },
  {
    id: 'b14',
    title: 'Eleanor Oliphant Is Completely Fine',
    author: 'Gail Honeyman',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1494170726i/33890488.jpg',
    synopsis:
      'Eleanor Oliphant leads a simple life. She wears the same clothes to work every day, eats the same lunch, and drinks two bottles of vodka on weekends. But a chance encounter cracks open her carefully constructed world.',
    averageRating: 4.2,
  },
  {
    id: 'b15',
    title: 'Educated',
    author: 'Tara Westover',
    coverUrl:
      'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1501187308i/36158060.jpg',
    synopsis:
      'Born to survivalists in the mountains of Idaho, Tara never set foot in a classroom. She taught herself enough to enter university, where her quest for knowledge would take her across continents and through the deepest questions of self.',
    averageRating: 4.5,
  },
];

export const LIBRARY_TRACKS: LibraryTrack[] = [
  { id: 'lib-1', title: 'Midnight Reverie — Ambient', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
  { id: 'lib-2', title: 'Soft Rain — Lo-Fi', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
  { id: 'lib-3', title: 'Distant Stars — Ambient', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
  { id: 'lib-4', title: 'Velvet Dusk — Chill', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3' },
  { id: 'lib-5', title: 'Quiet Pages — Piano', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3' },
  { id: 'lib-6', title: 'Golden Hour — Ambient', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3' },
];

export const DEMO_POSTS: Post[] = [
  {
    id: 'p1',
    type: 'quote',
    bookId: 'b1',
    text: '"The only way to learn is to live. And the only way to live is to be willing to learn."',
    username: 'nightreader',
    songTitle: 'Nightcall — Kavinsky',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[0].url,
    audioTrimStart: 0,
    audioTrimEnd: 20,
    likes: 1284,
    liked: false,
    saved: false,
    comments: [
      { id: 'c1', username: 'bookishsoul', text: 'this hit me at 2am' },
      { id: 'c2', username: 'mariposa', text: 'currently sobbing in this cafe' },
    ],
    createdAt: '2024-09-20',
  },
  {
    id: 'p2',
    type: 'review',
    bookId: 'b2',
    text: 'Sally Rooney writes intimacy like no one else. Every silence between Connell and Marianne felt heavier than any dialogue. I finished it and stared at the wall for an hour.',
    username: 'proseandpoetry',
    rating: 5,
    songTitle: 'Someone Like You — Adele',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[1].url,
    audioTrimStart: 0,
    audioTrimEnd: 22,
    likes: 892,
    liked: false,
    saved: false,
    comments: [
      { id: 'c3', username: 'dublinbound', text: 'the wall stare is real' },
    ],
    createdAt: '2024-09-18',
  },
  {
    id: 'p3',
    type: 'quote',
    bookId: 'b3',
    text: '"Things were bad. Things were very bad. He did not know if he would ever be able to be okay. But he was not dead, and so there was still a chance."',
    username: 'judeandme',
    songTitle: 'To Build a Home — The Cinematic Orchestra',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[2].url,
    audioTrimStart: 0,
    audioTrimEnd: 25,
    likes: 2310,
    liked: false,
    saved: false,
    comments: [
      { id: 'c4', username: 'gentleghost', text: 'I cannot read this without crying' },
      { id: 'c5', username: 'softspine', text: 'this book broke me permanently' },
      { id: 'c6', username: 'readerinwinter', text: 'the most devastating sentence in literature' },
    ],
    createdAt: '2024-09-15',
  },
  {
    id: 'p4',
    type: 'review',
    bookId: 'b4',
    text: 'Donna Tartt understands obsession. The way she builds the slow rot of guilt among friends — it is claustrophobic and gorgeous. A perfect autumn read.',
    username: 'darkacademia',
    rating: 5,
    songTitle: 'Rhiannon — Fleetwood Mac',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[3].url,
    audioTrimStart: 0,
    audioTrimEnd: 18,
    likes: 1567,
    liked: false,
    saved: false,
    comments: [
      { id: 'c7', username: 'greekmyth', text: 'reading this in october is mandatory' },
    ],
    createdAt: '2024-09-22',
  },
  {
    id: 'p5',
    type: 'quote',
    bookId: 'b5',
    text: '"That was the thing about the world — it never actually ended. You just kept playing."',
    username: 'pixelheart',
    songTitle: 'Nuvole Bianche — Ludovico Einaudi',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[4].url,
    audioTrimStart: 0,
    audioTrimEnd: 24,
    likes: 1789,
    liked: false,
    saved: false,
    comments: [
      { id: 'c8', username: 'gamergirl', text: 'this book understood me' },
    ],
    createdAt: '2024-09-19',
  },
  {
    id: 'p6',
    type: 'review',
    bookId: 'b6',
    text: 'Four generations, one family, and a history that refuses to stay buried. Min Jin Lee writes with such quiet dignity that the smallest moments land like earthquakes.',
    username: 'seoulsister',
    rating: 5,
    songTitle: 'Arirang — Traditional',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[5].url,
    audioTrimStart: 0,
    audioTrimEnd: 20,
    likes: 1103,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-17',
  },
  {
    id: 'p7',
    type: 'quote',
    bookId: 'b7',
    text: '"And isnt everything, in the end, a question of beauty? The beautiful thing about a bomb is that it works. The beautiful thing about a painting is that it survives."',
    username: 'goldfinchgirl',
    songTitle: 'Hallelujah — Jeff Buckley',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[0].url,
    audioTrimStart: 0,
    audioTrimEnd: 26,
    likes: 945,
    liked: false,
    saved: false,
    comments: [
      { id: 'c9', username: 'artthief', text: 'the painting lives rent free in my head' },
    ],
    createdAt: '2024-09-14',
  },
  {
    id: 'p8',
    type: 'review',
    bookId: 'b8',
    text: 'Rooney at her most uncomfortable. The power dynamics will make you squirm, but the prose is so clean it cuts. Not for everyone, but I could not look away.',
    username: 'quietcritic',
    rating: 4,
    songTitle: 'Motion Sickness — Phoebe Bridgers',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[1].url,
    audioTrimStart: 0,
    audioTrimEnd: 19,
    likes: 678,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-21',
  },
  {
    id: 'p9',
    type: 'quote',
    bookId: 'b9',
    text: '"I wanted to sleep until I was no longer tired. I wanted to sleep until the world was a place I wanted to wake up in."',
    username: 'sleepless',
    songTitle: 'Night Moves — Bob Seger',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[2].url,
    audioTrimStart: 0,
    audioTrimEnd: 21,
    likes: 1456,
    liked: false,
    saved: false,
    comments: [
      { id: 'c10', username: 'insomniac', text: 'felt this in my bones' },
    ],
    createdAt: '2024-09-16',
  },
  {
    id: 'p10',
    type: 'review',
    bookId: 'b10',
    text: 'Miller gives voice to a woman the myths only whispered about. Circe is fierce, lonely, and ultimately her own. I have never rooted harder for a witch.',
    username: 'mythmaker',
    rating: 5,
    songTitle: 'Ritual — Florence + The Machine',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[3].url,
    audioTrimStart: 0,
    audioTrimEnd: 23,
    likes: 2012,
    liked: false,
    saved: false,
    comments: [
      { id: 'c11', username: 'witchywoman', text: 'CIRCE DESERVES THE WORLD' },
      { id: 'c12', username: 'olympusbound', text: 'better than the original myths fight me' },
    ],
    createdAt: '2024-09-23',
  },
  {
    id: 'p11',
    type: 'quote',
    bookId: 'b11',
    text: '"We dont get to choose who we love. We only get to choose what we do with that love."',
    username: 'evelynfan',
    songTitle: 'Dreams — Fleetwood Mac',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[4].url,
    audioTrimStart: 0,
    audioTrimEnd: 20,
    likes: 2890,
    liked: false,
    saved: false,
    comments: [
      { id: 'c13', username: 'hollywoodnights', text: 'Evelyn Hugo is my roman empire' },
    ],
    createdAt: '2024-09-24',
  },
  {
    id: 'p12',
    type: 'review',
    bookId: 'b12',
    text: 'A murder mystery wrapped in a nature diary wrapped in a love letter to the marsh. Owens writes the Carolina coast like it is a living, breathing character.',
    username: 'marshbird',
    rating: 4,
    songTitle: 'Blue — Joni Mitchell',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[5].url,
    audioTrimStart: 0,
    audioTrimEnd: 22,
    likes: 1234,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-13',
  },
  {
    id: 'p13',
    type: 'quote',
    bookId: 'b13',
    text: '"We were like gods at the dawning of the world, and our joy was so great we could not bear it."',
    username: 'achillessorrow',
    songTitle: 'The Blowers Daughter — Damien Rice',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[0].url,
    audioTrimStart: 0,
    audioTrimEnd: 25,
    likes: 3102,
    liked: false,
    saved: false,
    comments: [
      { id: 'c14', username: 'patroclusdeservedbetter', text: 'I am not okay and I never will be' },
      { id: 'c15', username: 'greeksong', text: 'this quote lives in my chest' },
    ],
    createdAt: '2024-09-25',
  },
  {
    id: 'p14',
    type: 'review',
    bookId: 'b14',
    text: 'Eleanor is prickly, strange, and deeply wounded. Honeyman lets you laugh before she breaks your heart. The slow thaw is worth every page.',
    username: 'quietpages',
    rating: 4,
    songTitle: 'Everybody Hurts — R.E.M.',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[1].url,
    audioTrimStart: 0,
    audioTrimEnd: 18,
    likes: 867,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-12',
  },
  {
    id: 'p15',
    type: 'quote',
    bookId: 'b15',
    text: '"You can love someone and still choose to say goodbye to them. You can miss a person every day, and still be glad that they are no longer in your life."',
    username: 'mountaindaughter',
    songTitle: 'Fast Car — Tracy Chapman',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[2].url,
    audioTrimStart: 0,
    audioTrimEnd: 24,
    likes: 1945,
    liked: false,
    saved: false,
    comments: [
      { id: 'c16', username: 'wildflower', text: 'this one hurts differently' },
    ],
    createdAt: '2024-09-11',
  },
  {
    id: 'p16',
    type: 'quote',
    bookId: 'b1',
    text: '"Regret is a ridiculous thing. You can only live the life you have."',
    username: 'libraryghost',
    songTitle: 'Landslide — Fleetwood Mac',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[3].url,
    audioTrimStart: 0,
    audioTrimEnd: 20,
    likes: 1678,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-10',
  },
  {
    id: 'p17',
    type: 'review',
    bookId: 'b5',
    text: 'Zevin writes about friendship the way most books write about romance — with longing, jealousy, and devotion. The best novel about making things with someone I have ever read.',
    username: 'cooperativeplay',
    rating: 5,
    songTitle: 'Video Game Music — Lana Del Rey',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[4].url,
    audioTrimStart: 0,
    audioTrimEnd: 22,
    likes: 1342,
    liked: false,
    saved: false,
    comments: [
      { id: 'c17', username: 'sadieandmax', text: 'Sam and Sadie are my parents now' },
    ],
    createdAt: '2024-09-09',
  },
  {
    id: 'p18',
    type: 'quote',
    bookId: 'b4',
    text: '"Beauty is terror. Whatever we are, whatever we make, is in some sense a response to the terror of beauty."',
    username: 'greekclass',
    songTitle: 'All Mine — Portishead',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[5].url,
    audioTrimStart: 0,
    audioTrimEnd: 19,
    likes: 1123,
    liked: false,
    saved: false,
    comments: [],
    createdAt: '2024-09-08',
  },
  {
    id: 'p19',
    type: 'review',
    bookId: 'b11',
    text: 'Taylor Jenkins Reid writes Hollywood glamour with a knife hidden in the silk dress. Evelyn Hugo is the most fully realized character I have met in years. The ending wrecked me.',
    username: 'silvercreen',
    rating: 5,
    songTitle: 'Young and Beautiful — Lana Del Rey',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[0].url,
    audioTrimStart: 0,
    audioTrimEnd: 26,
    likes: 2567,
    liked: false,
    saved: false,
    comments: [
      { id: 'c18', username: 'monicastan', text: 'I think about Monique constantly' },
    ],
    createdAt: '2024-09-26',
  },
  {
    id: 'p20',
    type: 'quote',
    bookId: 'b10',
    text: '"I was not made for the world of men. I was made for the wild, for the island, for the sea, and for the dark."',
    username: 'islandwitch',
    songTitle: 'Cosmic Love — Florence + The Machine',
    audioSource: 'library',
    audioUrl: LIBRARY_TRACKS[1].url,
    audioTrimStart: 0,
    audioTrimEnd: 23,
    likes: 1789,
    liked: false,
    saved: false,
    comments: [
      { id: 'c19', username: 'aeaea', text: 'this is my villain origin story' },
    ],
    createdAt: '2024-09-27',
  },
];
