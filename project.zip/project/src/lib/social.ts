import { supabase } from '@/lib/supabase';
import type { PostRow, Profile, CommentRow, NotificationRow, TbrRow } from '@/lib/supabase';

export interface PostWithMeta extends PostRow {
  likeCount: number;
  commentCount: number;
  liked: boolean;
  saved: boolean;
  author: Profile | null;
}

export async function fetchPosts(type: 'quote' | 'review' | 'all' = 'all'): Promise<PostWithMeta[]> {
  let query = supabase.from('posts').select('*').order('created_at', { ascending: false });
  if (type !== 'all') query = query.eq('type', type);
  const { data: posts, error } = await query;
  if (error || !posts) return [];

  return enrichPosts(posts as PostRow[]);
}

export async function fetchPostsByUser(userId: string): Promise<PostWithMeta[]> {
  const { data: posts } = await supabase
    .from('posts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (!posts) return [];
  return enrichPosts(posts as PostRow[]);
}

export async function fetchLikedPosts(userId: string): Promise<PostWithMeta[]> {
  const { data: likes } = await supabase
    .from('likes')
    .select('post_id')
    .eq('user_id', userId);
  if (!likes || likes.length === 0) return [];

  const postIds = likes.map((l) => l.post_id);
  const { data: posts } = await supabase
    .from('posts')
    .select('*')
    .in('id', postIds)
    .order('created_at', { ascending: false });
  if (!posts) return [];
  return enrichPosts(posts as PostRow[]);
}

export async function fetchSavedPosts(userId: string): Promise<PostWithMeta[]> {
  const { data: saves } = await supabase
    .from('saves')
    .select('post_id')
    .eq('user_id', userId);
  if (!saves || saves.length === 0) return [];

  const postIds = saves.map((s) => s.post_id);
  const { data: posts } = await supabase
    .from('posts')
    .select('*')
    .in('id', postIds)
    .order('created_at', { ascending: false });
  if (!posts) return [];
  return enrichPosts(posts as PostRow[]);
}

async function enrichPosts(posts: PostRow[]): Promise<PostWithMeta[]> {
  if (posts.length === 0) return [];

  const postIds = posts.map((p) => p.id);
  const userIds = [...new Set(posts.map((p) => p.user_id))];

  const [likesRes, savesRes, commentsRes, profilesRes] = await Promise.all([
    supabase.from('likes').select('post_id, user_id').in('post_id', postIds),
    supabase.from('saves').select('post_id, user_id').in('post_id', postIds),
    supabase.from('comments').select('post_id').in('post_id', postIds),
    supabase.from('profiles').select('*').in('id', userIds),
  ]);

  const likeMap = new Map<string, Set<string>>();
  (likesRes.data || []).forEach((l) => {
    if (!likeMap.has(l.post_id)) likeMap.set(l.post_id, new Set());
    likeMap.get(l.post_id)!.add(l.user_id);
  });

  const saveMap = new Map<string, Set<string>>();
  (savesRes.data || []).forEach((s) => {
    if (!saveMap.has(s.post_id)) saveMap.set(s.post_id, new Set());
    saveMap.get(s.post_id)!.add(s.user_id);
  });

  const commentCountMap = new Map<string, number>();
  (commentsRes.data || []).forEach((c) => {
    commentCountMap.set(c.post_id, (commentCountMap.get(c.post_id) || 0) + 1);
  });

  const profileMap = new Map<string, Profile>();
  (profilesRes.data || []).forEach((p) => profileMap.set(p.id, p as Profile));

  const currentUserId = (await supabase.auth.getUser()).data.user?.id;

  return posts.map((p) => ({
    ...p,
    likeCount: likeMap.get(p.id)?.size || 0,
    commentCount: commentCountMap.get(p.id) || 0,
    liked: currentUserId ? (likeMap.get(p.id)?.has(currentUserId) ?? false) : false,
    saved: currentUserId ? (saveMap.get(p.id)?.has(currentUserId) ?? false) : false,
    author: profileMap.get(p.user_id) ?? null,
  }));
}

export async function toggleLike(postId: string, userId: string, currentlyLiked: boolean) {
  if (currentlyLiked) {
    await supabase.from('likes').delete().eq('post_id', postId).eq('user_id', userId);
  } else {
    await supabase.from('likes').insert({ post_id: postId, user_id: userId });
    const { data: post } = await supabase.from('posts').select('user_id').eq('id', postId).maybeSingle();
    if (post && post.user_id !== userId) {
      await supabase.from('notifications').insert({
        user_id: post.user_id,
        actor_id: userId,
        type: 'like',
        post_id: postId,
        text: 'liked your post',
      });
    }
  }
}

export async function toggleSave(postId: string, userId: string, currentlySaved: boolean) {
  if (currentlySaved) {
    await supabase.from('saves').delete().eq('post_id', postId).eq('user_id', userId);
  } else {
    await supabase.from('saves').insert({ post_id: postId, user_id: userId });
  }
}

export async function fetchComments(postId: string): Promise<(CommentRow & { author: Profile | null })[]> {
  const { data: comments } = await supabase
    .from('comments')
    .select('*')
    .eq('post_id', postId)
    .order('created_at', { ascending: true });
  if (!comments || comments.length === 0) return [];

  const userIds = [...new Set(comments.map((c) => c.user_id))];
  const { data: profiles } = await supabase.from('profiles').select('*').in('id', userIds);
  const profileMap = new Map<string, Profile>();
  (profiles || []).forEach((p) => profileMap.set(p.id, p as Profile));

  return (comments as CommentRow[]).map((c) => ({ ...c, author: profileMap.get(c.user_id) ?? null }));
}

export async function addComment(postId: string, userId: string, text: string, parentId?: string) {
  const { data: comment } = await supabase
    .from('comments')
    .insert({ post_id: postId, user_id: userId, text, parent_id: parentId ?? null })
    .select('*')
    .single();
  if (comment) {
    const { data: post } = await supabase.from('posts').select('user_id').eq('id', postId).maybeSingle();
    if (post && post.user_id !== userId) {
      await supabase.from('notifications').insert({
        user_id: post.user_id,
        actor_id: userId,
        type: 'comment',
        post_id: postId,
        text: 'commented on your post',
      });
    }
  }
  return comment;
}

export async function createPost(data: {
  user_id: string;
  type: 'quote' | 'review';
  text: string;
  book_id: string;
  book_title: string;
  book_author: string;
  book_cover: string;
  rating: number;
  song_title: string;
  audio_url: string;
  audio_source: string;
  audio_trim_start: number;
  audio_trim_end: number;
}) {
  const { data: post, error } = await supabase.from('posts').insert(data).select('*').single();
  return { post, error };
}

export async function searchProfiles(query: string): Promise<Profile[]> {
  if (!query.trim()) return [];
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .or(`username.ilike.%${query}%,display_name.ilike.%${query}%`)
    .limit(20);
  return (data || []) as Profile[];
}

export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  return data as Profile | null;
}

export async function updateProfile(userId: string, updates: Partial<Pick<Profile, 'username' | 'display_name' | 'bio' | 'avatar_url'>>) {
  const { data, error } = await supabase.from('profiles').update(updates).eq('id', userId).select('*').maybeSingle();
  return { data: data as Profile | null, error };
}

export async function fetchFollowerCount(userId: string): Promise<number> {
  const { count } = await supabase.from('follows').select('*', { count: 'exact', head: true }).eq('following_id', userId);
  return count || 0;
}

export async function fetchFollowingCount(userId: string): Promise<number> {
  const { count } = await supabase.from('follows').select('*', { count: 'exact', head: true }).eq('follower_id', userId);
  return count || 0;
}

export async function isFollowing(followerId: string, followingId: string): Promise<boolean> {
  const { data } = await supabase
    .from('follows')
    .select('id')
    .eq('follower_id', followerId)
    .eq('following_id', followingId)
    .maybeSingle();
  return !!data;
}

export async function toggleFollow(followerId: string, followingId: string, currentlyFollowing: boolean) {
  if (currentlyFollowing) {
    await supabase.from('follows').delete().eq('follower_id', followerId).eq('following_id', followingId);
  } else {
    await supabase.from('follows').insert({ follower_id: followerId, following_id: followingId });
    await supabase.from('notifications').insert({
      user_id: followingId,
      actor_id: followerId,
      type: 'follow',
      text: 'started following you',
    });
  }
}

export async function fetchFollowers(userId: string): Promise<Profile[]> {
  const { data } = await supabase
    .from('follows')
    .select('follower_id')
    .eq('following_id', userId);
  if (!data || data.length === 0) return [];
  const ids = data.map((f) => f.follower_id);
  const { data: profiles } = await supabase.from('profiles').select('*').in('id', ids);
  return (profiles || []) as Profile[];
}

export async function fetchFollowing(userId: string): Promise<Profile[]> {
  const { data } = await supabase
    .from('follows')
    .select('following_id')
    .eq('follower_id', userId);
  if (!data || data.length === 0) return [];
  const ids = data.map((f) => f.following_id);
  const { data: profiles } = await supabase.from('profiles').select('*').in('id', ids);
  return (profiles || []) as Profile[];
}

export async function fetchNotifications(userId: string): Promise<(NotificationRow & { actor: Profile | null })[]> {
  const { data: notifs } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (!notifs || notifs.length === 0) return [];

  const actorIds = [...new Set(notifs.map((n) => n.actor_id).filter(Boolean))] as string[];
  const { data: profiles } = await supabase.from('profiles').select('*').in('id', actorIds);
  const profileMap = new Map<string, Profile>();
  (profiles || []).forEach((p) => profileMap.set(p.id, p as Profile));

  return (notifs as NotificationRow[]).map((n) => ({
    ...n,
    actor: n.actor_id ? profileMap.get(n.actor_id) ?? null : null,
  }));
}

export async function markNotificationsRead(userId: string) {
  await supabase.from('notifications').update({ read: true }).eq('user_id', userId).eq('read', false);
}

export async function fetchUnreadNotificationCount(userId: string): Promise<number> {
  const { count } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('read', false);
  return count || 0;
}

export async function fetchTbr(userId: string, status?: 'want' | 'reading' | 'read'): Promise<TbrRow[]> {
  let query = supabase.from('tbr').select('*').eq('user_id', userId).order('updated_at', { ascending: false });
  if (status) query = query.eq('status', status);
  const { data } = await query;
  return (data || []) as TbrRow[];
}

export async function upsertTbr(data: {
  user_id: string;
  book_id: string;
  book_title: string;
  book_author: string;
  book_cover: string;
  status: 'want' | 'reading' | 'read';
}) {
  const { error } = await supabase
    .from('tbr')
    .upsert(data, { onConflict: 'user_id,book_id' });
  return { error };
}

export async function removeTbr(userId: string, bookId: string) {
  await supabase.from('tbr').delete().eq('user_id', userId).eq('book_id', bookId);
}
