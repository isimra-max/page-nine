import { supabase } from '@/lib/supabase';
import type { ConversationRow, MessageRow, Profile } from '@/lib/supabase';

export interface ConversationWithOther extends ConversationRow {
  otherUser: Profile | null;
  lastMessage: MessageRow | null;
  unreadCount: number;
}

export async function fetchConversations(userId: string): Promise<ConversationWithOther[]> {
  const { data: convos } = await supabase
    .from('conversations')
    .select('*')
    .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
    .order('created_at', { ascending: false });
  if (!convos || convos.length === 0) return [];

  const convosData = convos as ConversationRow[];
  const otherIds = convosData.map((c) => (c.user1_id === userId ? c.user2_id : c.user1_id));

  const { data: profiles } = await supabase.from('profiles').select('*').in('id', otherIds);
  const profileMap = new Map<string, Profile>();
  (profiles || []).forEach((p) => profileMap.set(p.id, p as Profile));

  const convoIds = convosData.map((c) => c.id);
  const { data: messages } = await supabase
    .from('messages')
    .select('*')
    .in('conversation_id', convoIds)
    .order('created_at', { ascending: false });

  const lastMessageMap = new Map<string, MessageRow>();
  const unreadMap = new Map<string, number>();
  (messages || []).forEach((m) => {
    const msg = m as MessageRow;
    if (!lastMessageMap.has(msg.conversation_id)) {
      lastMessageMap.set(msg.conversation_id, msg);
    }
    if (!msg.read && msg.sender_id !== userId) {
      unreadMap.set(msg.conversation_id, (unreadMap.get(msg.conversation_id) || 0) + 1);
    }
  });

  return convosData.map((c) => ({
    ...c,
    otherUser: profileMap.get(c.user1_id === userId ? c.user2_id : c.user1_id) ?? null,
    lastMessage: lastMessageMap.get(c.id) ?? null,
    unreadCount: unreadMap.get(c.id) || 0,
  }));
}

export async function fetchMessages(conversationId: string): Promise<MessageRow[]> {
  const { data } = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });
  return (data || []) as MessageRow[];
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  text: string,
  extra?: { sharedPostId?: string; sharedBookTitle?: string; sharedBookAuthor?: string; sharedBookCover?: string }
) {
  const { data, error } = await supabase.from('messages').insert({
    conversation_id: conversationId,
    sender_id: senderId,
    text,
    shared_post_id: extra?.sharedPostId ?? null,
    shared_book_title: extra?.sharedBookTitle ?? '',
    shared_book_author: extra?.sharedBookAuthor ?? '',
    shared_book_cover: extra?.sharedBookCover ?? '',
  }).select('*').single();

  if (data && !error) {
    const { data: convo } = await supabase
      .from('conversations')
      .select('user1_id, user2_id')
      .eq('id', conversationId)
      .maybeSingle();
    if (convo) {
      const recipientId = convo.user1_id === senderId ? convo.user2_id : convo.user1_id;
      await supabase.from('notifications').insert({
        user_id: recipientId,
        actor_id: senderId,
        type: 'message',
        text: 'sent you a message',
      });
    }
  }
  return { data: data as MessageRow | null, error };
}

export async function markMessagesRead(conversationId: string, userId: string) {
  await supabase
    .from('messages')
    .update({ read: true })
    .eq('conversation_id', conversationId)
    .neq('sender_id', userId);
}

export async function getOrCreateConversation(user1Id: string, user2Id: string): Promise<string | null> {
  const [minId, maxId] = user1Id < user2Id ? [user1Id, user2Id] : [user2Id, user1Id];

  const { data: existing } = await supabase
    .from('conversations')
    .select('id')
    .eq('user1_id', minId)
    .eq('user2_id', maxId)
    .maybeSingle();

  if (existing) return existing.id;

  const { data: newConvo, error } = await supabase
    .from('conversations')
    .insert({ user1_id: minId, user2_id: maxId })
    .select('id')
    .single();

  if (error || !newConvo) return null;
  return newConvo.id;
}

export async function fetchUnreadMessageCount(userId: string): Promise<number> {
  const { data: convos } = await supabase
    .from('conversations')
    .select('id')
    .or(`user1_id.eq.${userId},user2_id.eq.${userId}`);
  if (!convos || convos.length === 0) return 0;

  const convoIds = convos.map((c) => c.id);
  const { count } = await supabase
    .from('messages')
    .select('*', { count: 'exact', head: true })
    .in('conversation_id', convoIds)
    .neq('sender_id', userId)
    .eq('read', false);
  return count || 0;
}
