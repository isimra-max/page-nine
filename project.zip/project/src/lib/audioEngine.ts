export interface AudioTrack {
  url: string;
  trimStart?: number;
  trimEnd?: number;
  title: string;
}

const FADE_DURATION = 400;

export class AudioEngine {
  private audio: HTMLAudioElement | null = null;
  private currentTrack: AudioTrack | null = null;
  private muted = false;
  private playing = false;
  private userPaused = false;
  private loadError = false;
  private fadeTimer: number | null = null;
  private onStateChange: (() => void) | null = null;
  private pendingTrack: AudioTrack | null = null;
  private audioUnlocked = false;
  private preloadedUrls = new Set<string>();
  private interactionListener: (() => void) | null = null;

  setOnStateChange(cb: () => void) {
    this.onStateChange = cb;
  }

  private notify() {
    this.onStateChange?.();
  }

  private clearFadeTimer() {
    if (this.fadeTimer !== null) {
      clearInterval(this.fadeTimer);
      this.fadeTimer = null;
    }
  }

  private fadeVolume(from: number, to: number, duration: number, onDone?: () => void) {
    this.clearFadeTimer();
    const steps = Math.max(1, Math.round(duration / 50));
    const increment = (to - from) / steps;
    let current = from;
    let count = 0;
    this.fadeTimer = window.setInterval(() => {
      count++;
      current += increment;
      if (count >= steps) {
        if (this.audio) this.audio.volume = to;
        this.clearFadeTimer();
        onDone?.();
      } else if (this.audio) {
        this.audio.volume = Math.max(0, Math.min(1, current));
      }
    }, 50);
  }

  private setupAudioEvents(audio: HTMLAudioElement) {
    audio.addEventListener('error', () => {
      this.loadError = true;
      this.playing = false;
      this.notify();
    });
    audio.addEventListener('canplay', () => {
      this.loadError = false;
      this.notify();
    });
    audio.addEventListener('playing', () => {
      this.playing = true;
      this.notify();
    });
    audio.addEventListener('pause', () => {
      if (!this.userPaused) {
        this.playing = false;
        this.notify();
      }
    });
  }

  private addInteractionListener() {
    if (this.interactionListener) return;
    const handler = () => {
      this.audioUnlocked = true;
      if (this.pendingTrack) {
        const track = this.pendingTrack;
        this.pendingTrack = null;
        this.playTrack(track);
      }
      this.notify();
    };
    this.interactionListener = handler;
    document.addEventListener('click', handler);
    document.addEventListener('touchstart', handler);
    document.addEventListener('keydown', handler);
  }

  preload(url: string) {
    if (this.preloadedUrls.has(url)) return;
    this.preloadedUrls.add(url);
    const a = new Audio(url);
    a.preload = 'auto';
    a.volume = 0;
    a.load();
  }

  playTrack(track: AudioTrack) {
    // If same URL is already loaded and not user-paused, do nothing
    if (this.currentTrack && this.currentTrack.url === track.url && !this.userPaused) {
      return;
    }

    // Stop existing audio immediately
    this.clearFadeTimer();
    if (this.audio) {
      this.audio.pause();
      this.audio.src = '';
      this.audio = null;
    }

    this.currentTrack = track;
    this.userPaused = false;
    this.loadError = false;

    const audio = new Audio(track.url);
    audio.preload = 'auto';
    audio.loop = true;
    audio.volume = this.muted ? 0 : 0;
    this.setupAudioEvents(audio);
    this.audio = audio;

    const trimStart = track.trimStart ?? 0;
    audio.currentTime = trimStart;

    const trimEnd = track.trimEnd;
    if (trimEnd !== undefined) {
      audio.addEventListener('timeupdate', () => {
        if (audio.currentTime >= trimEnd) {
          audio.currentTime = trimStart;
        }
      });
    }

    const playPromise = audio.play();
    if (playPromise) {
      playPromise.then(() => {
        this.audioUnlocked = true;
        this.fadeVolume(0, this.muted ? 0 : 1, FADE_DURATION);
        this.playing = true;
        this.pendingTrack = null;
        this.notify();
      }).catch(() => {
        // Browser blocked autoplay — store track and wait for user interaction
        this.pendingTrack = track;
        this.playing = false;
        this.addInteractionListener();
        this.notify();
      });
    }
  }

  stop() {
    this.clearFadeTimer();
    if (this.audio) {
      this.audio.pause();
      this.audio.src = '';
      this.audio = null;
    }
    this.currentTrack = null;
    this.playing = false;
    this.userPaused = false;
    this.notify();
  }

  pause() {
    if (!this.audio) return;
    this.clearFadeTimer();
    this.fadeVolume(this.audio.volume, 0, 200, () => {
      if (this.audio) this.audio.pause();
    });
    this.playing = false;
    this.userPaused = true;
    this.notify();
  }

  resume() {
    if (!this.audio) return;
    this.userPaused = false;
    if (this.audio.paused) {
      const playPromise = this.audio.play();
      if (playPromise) {
        playPromise.then(() => {
          this.fadeVolume(0, this.muted ? 0 : 1, 200);
          this.playing = true;
          this.notify();
        }).catch(() => {
          this.playing = false;
          this.notify();
        });
      }
    } else {
      this.fadeVolume(this.audio.volume, this.muted ? 0 : 1, 200);
      this.playing = true;
      this.notify();
    }
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.audio && this.playing) {
      this.clearFadeTimer();
      this.fadeVolume(this.audio.volume, muted ? 0 : 1, 200);
    }
    this.notify();
  }

  isMuted() {
    return this.muted;
  }

  isPlaying() {
    return this.playing;
  }

  isUserPaused() {
    return this.userPaused;
  }

  isAudioUnlocked() {
    return this.audioUnlocked;
  }

  hasPendingTrack() {
    return this.pendingTrack !== null;
  }

  hasLoadError() {
    return this.loadError;
  }

  getCurrentTitle() {
    return this.currentTrack?.title ?? '';
  }

  getCurrentUrl() {
    return this.currentTrack?.url ?? '';
  }

  getCurrentTime() {
    return this.audio?.currentTime ?? 0;
  }

  isAudioPaused() {
    return this.audio?.paused ?? true;
  }

  unlock() {
    this.audioUnlocked = true;
    if (this.pendingTrack) {
      const track = this.pendingTrack;
      this.pendingTrack = null;
      this.playTrack(track);
    }
    this.notify();
  }

  destroy() {
    this.clearFadeTimer();
    if (this.audio) {
      this.audio.pause();
      this.audio.src = '';
      this.audio = null;
    }
    if (this.interactionListener) {
      document.removeEventListener('click', this.interactionListener);
      document.removeEventListener('touchstart', this.interactionListener);
      document.removeEventListener('keydown', this.interactionListener);
      this.interactionListener = null;
    }
    this.currentTrack = null;
    this.playing = false;
    this.pendingTrack = null;
  }
}

export const audioEngine = new AudioEngine();
