import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export interface Profile {
  id: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  created_at: string;
}

export interface PostRow {
  id: string;
  user_id: string;
  type: 'quote' | 'review';
  text: string;
  book_id: string;
  book_title: string;
  book_author: string;
  book_cover: string;
  rating: number;
  song_title: string;
  audio_url: string;
  audio_source: string;
  audio_trim_start: number;
  audio_trim_end: number;
  created_at: string;
}

export interface CommentRow {
  id: string;
  user_id: string;
  post_id: string;
  parent_id: string | null;
  text: string;
  created_at: string;
}

export interface NotificationRow {
  id: string;
  user_id: string;
  actor_id: string | null;
  type: 'follow' | 'like' | 'comment' | 'share' | 'message';
  post_id: string | null;
  text: string;
  read: boolean;
  created_at: string;
}

export interface ConversationRow {
  id: string;
  user1_id: string;
  user2_id: string;
  created_at: string;
}

export interface MessageRow {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  shared_post_id: string | null;
  shared_book_title: string;
  shared_book_author: string;
  shared_book_cover: string;
  read: boolean;
  created_at: string;
}

export interface TbrRow {
  id: string;
  user_id: string;
  book_id: string;
  book_title: string;
  book_author: string;
  book_cover: string;
  status: 'want' | 'reading' | 'read';
  created_at: string;
  updated_at: string;
}
