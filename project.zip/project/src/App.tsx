import { useState, useMemo, useCallback, useEffect } from 'react';
import { Plus, Quote, Star, BookOpen, Volume2, VolumeX, Bell, MessageSquare, Search, User } from 'lucide-react';
import { BOOKS } from '@/data';
import type { Book, Post } from '@/data';
import { ReelFeed } from '@/components/ReelFeed';
import { BookPage } from '@/components/BookPage';
import { CreatePostModal } from '@/components/CreatePostModal';
import { CommentDrawer } from '@/components/CommentDrawer';
import { AtmosphericBackground } from '@/components/AtmosphericBackground';
import { AuthScreen } from '@/components/AuthScreen';
import { ProfilePage } from '@/components/ProfilePage';
import { MessagesScreen } from '@/components/MessagesScreen';
import { NotificationsScreen } from '@/components/NotificationsScreen';
import { SearchScreen } from '@/components/SearchScreen';
import { useAudioEngine } from '@/hooks/useAudioEngine';
import { useAuth } from '@/hooks/useAuth';
import { fetchPosts, toggleLike as dbToggleLike, toggleSave as dbToggleSave, createPost, type PostWithMeta } from '@/lib/social';
import { fetchUnreadNotificationCount } from '@/lib/social';
import { fetchUnreadMessageCount } from '@/lib/messaging';

type Tab = 'quotes' | 'reviews';
type View = 'reel' | 'book' | 'profile' | 'messages' | 'notifications' | 'search';

export default function App() {
  const { user, profile, loading } = useAuth();
  const [tab, setTab] = useState<Tab>('quotes');
  const [view, setView] = useState<View>('reel');
  const [activeBook, setActiveBook] = useState<Book | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [createPreselect, setCreatePreselect] = useState<Book | null>(null);
  const [commentPost, setCommentPost] = useState<PostWithMeta | null>(null);
  const [posts, setPosts] = useState<PostWithMeta[]>([]);
  const [postsLoading, setPostsLoading] = useState(true);
  const [postsError, setPostsError] = useState<string | null>(null);
  const [profileUserId, setProfileUserId] = useState<string | null>(null);
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [messagePreselect, setMessagePreselect] = useState<string | null>(null);
  const [sharedPostForMessage, setSharedPostForMessage] = useState<{ id: string; text: string; bookTitle: string } | null>(null);
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [authPrompt, setAuthPrompt] = useState(false);
  const { toggleMute, isMuted } = useAudioEngine();

  // Load posts from Supabase
  const loadPosts = useCallback(async () => {
    setPostsLoading(true);
    setPostsError(null);
    try {
      const fetched = await fetchPosts('all');
      setPosts(fetched);
    } catch (err) {
      setPostsError('Failed to load posts. Please try again.');
    } finally {
      setPostsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  // Load unread counts
  useEffect(() => {
    if (!user) {
      setUnreadNotifs(0);
      setUnreadMessages(0);
      return;
    }
    const load = async () => {
      setUnreadNotifs(await fetchUnreadNotificationCount(user.id));
      setUnreadMessages(await fetchUnreadMessageCount(user.id));
    };
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, [user]);

  const booksById = useMemo(() => {
    const map: Record<string, Book> = {};
    BOOKS.forEach((b) => (map[b.id] = b));
    return map;
  }, []);

  // Convert PostWithMeta to the Post type ReelCard expects
  const toPostType = useCallback((p: PostWithMeta): Post => ({
    id: p.id,
    type: p.type,
    bookId: p.book_id,
    text: p.text,
    username: p.author?.username ?? 'unknown',
    rating: p.rating || undefined,
    songTitle: p.song_title,
    audioUrl: p.audio_url || undefined,
    audioSource: (p.audio_source as 'library' | 'upload') || undefined,
    audioTrimStart: p.audio_trim_start || undefined,
    audioTrimEnd: p.audio_trim_end || undefined,
    likes: p.likeCount,
    liked: p.liked,
    saved: p.saved,
    comments: [],
    createdAt: p.created_at.slice(0, 10),
  }), []);

  const toBookType = useCallback((p: PostWithMeta): Book => ({
    id: p.book_id,
    title: p.book_title,
    author: p.book_author,
    coverUrl: p.book_cover,
    synopsis: '',
    averageRating: 0,
  }), []);

  const quotePosts = useMemo(() => posts.filter((p) => p.type === 'quote'), [posts]);
  const reviewPosts = useMemo(() => posts.filter((p) => p.type === 'review'), [posts]);

  const openBook = useCallback((book: Book) => {
    setActiveBook(book);
    setView('book');
  }, []);

  const openBookById = useCallback((bookId: string, title: string, author: string, cover: string) => {
    const book: Book = { id: bookId, title, author, coverUrl: cover, synopsis: '', averageRating: 0 };
    setActiveBook(book);
    setView('book');
  }, []);

  const backToReel = useCallback(() => {
    setView('reel');
    setActiveBook(null);
  }, []);

  const requireAuth = useCallback((): boolean => {
    if (!user) {
      setAuthPrompt(true);
      return false;
    }
    return true;
  }, [user]);

  const handleToggleLike = useCallback(async (postId: string) => {
    if (!requireAuth()) return;
    const post = posts.find((p) => p.id === postId);
    if (!post || !user) return;
    await dbToggleLike(postId, user.id, post.liked);
    setPosts((prev) => prev.map((p) =>
      p.id === postId
        ? { ...p, liked: !p.liked, likeCount: p.liked ? p.likeCount - 1 : p.likeCount + 1 }
        : p
    ));
  }, [posts, user, requireAuth]);

  const handleToggleSave = useCallback(async (postId: string) => {
    if (!requireAuth()) return;
    const post = posts.find((p) => p.id === postId);
    if (!post || !user) return;
    await dbToggleSave(postId, user.id, post.saved);
    setPosts((prev) => prev.map((p) =>
      p.id === postId ? { ...p, saved: !p.saved } : p
    ));
  }, [posts, user, requireAuth]);

  const handleOpenComments = useCallback((post: PostWithMeta) => {
    if (!requireAuth()) return;
    setCommentPost(post);
  }, [requireAuth]);

  const handleOpenProfile = useCallback((userId: string) => {
    setProfileUserId(userId);
    setView('profile');
  }, []);

  const handleOpenMessages = useCallback(() => {
    if (!requireAuth()) return;
    setView('messages');
    setActiveConversation(null);
    setMessagePreselect(null);
  }, [requireAuth]);

  const handleMessageUser = useCallback((userId: string) => {
    if (!requireAuth()) return;
    setMessagePreselect(userId);
    setView('messages');
    setActiveConversation(null);
  }, [requireAuth]);

  const handleOpenNotifications = useCallback(() => {
    if (!requireAuth()) return;
    setView('notifications');
  }, [requireAuth]);

  const handleOpenSearch = useCallback(() => {
    setView('search');
  }, []);

  const handleOpenCreate = useCallback((book?: Book) => {
    if (!requireAuth()) return;
    setCreatePreselect(book ?? null);
    setCreateOpen(true);
  }, [requireAuth]);

  const handlePublishPost = useCallback(async (data: {
    type: 'quote' | 'review';
    bookId: string;
    text: string;
    rating?: number;
    songTitle: string;
    audioUrl?: string;
    audioSource?: 'library' | 'upload';
    audioTrimStart?: number;
    audioTrimEnd?: number;
    bookTitle: string;
    bookAuthor: string;
    bookCover: string;
  }) => {
    if (!user) return;
    await createPost({
      user_id: user.id,
      type: data.type,
      text: data.text,
      book_id: data.bookId,
      book_title: data.bookTitle,
      book_author: data.bookAuthor,
      book_cover: data.bookCover,
      rating: data.rating || 0,
      song_title: data.songTitle,
      audio_url: data.audioUrl || '',
      audio_source: data.audioSource || '',
      audio_trim_start: data.audioTrimStart || 0,
      audio_trim_end: data.audioTrimEnd || 0,
    });
    setTab(data.type === 'quote' ? 'quotes' : 'reviews');
    setCreateOpen(false);
    setCreatePreselect(null);
    setView('reel');
    loadPosts();
  }, [user, loadPosts]);

  // Convert posts for ReelFeed
  const feedPosts = useMemo(() => {
    const source = tab === 'quotes' ? quotePosts : reviewPosts;
    return source.map(toPostType);
  }, [tab, quotePosts, reviewPosts, toPostType]);

  const feedBooks = useMemo(() => {
    const source = tab === 'quotes' ? quotePosts : reviewPosts;
    const map: Record<string, Book> = {};
    source.forEach((p) => { map[p.book_id] = toBookType(p); });
    return map;
  }, [tab, quotePosts, reviewPosts, toBookType]);

  // Show auth screen only if auth prompt triggered (not while loading auth - feed is public)

  if (authPrompt && !user) {
    return <AuthScreen />;
  }

  return (
    <div className="relative h-full w-full overflow-hidden bg-charcoal">
      <AtmosphericBackground />

      {/* Top glass header */}
      <header className="absolute left-0 right-0 top-0 z-30 flex items-center justify-between px-4 py-4 sm:px-8">
        <button onClick={() => setView('reel')} className="flex items-center gap-2">
          <BookOpen size={22} className="text-gold" />
          <span className="font-serif text-xl font-semibold tracking-tight text-cream">
            Page <span className="text-gradient-gold">Nine</span>
          </span>
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Search */}
          <button
            onClick={handleOpenSearch}
            className="flex items-center justify-center rounded-full glass p-2.5 text-cream/70 transition-all hover:text-cream"
          >
            <Search size={18} />
          </button>

          {/* Notifications */}
          <button
            onClick={handleOpenNotifications}
            className="relative flex items-center justify-center rounded-full glass p-2.5 text-cream/70 transition-all hover:text-cream"
          >
            <Bell size={18} />
            {unreadNotifs > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose px-1 text-[9px] font-bold text-charcoal">
                {unreadNotifs > 9 ? '9+' : unreadNotifs}
              </span>
            )}
          </button>

          {/* Messages */}
          <button
            onClick={handleOpenMessages}
            className="relative flex items-center justify-center rounded-full glass p-2.5 text-cream/70 transition-all hover:text-cream"
          >
            <MessageSquare size={18} />
            {unreadMessages > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose px-1 text-[9px] font-bold text-charcoal">
                {unreadMessages > 9 ? '9+' : unreadMessages}
              </span>
            )}
          </button>

          {/* Mute/Unmute */}
          <button
            onClick={toggleMute}
            className="flex items-center justify-center rounded-full glass p-2.5 text-cream/70 transition-all hover:text-cream"
          >
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>

          {/* Profile */}
          <button
            onClick={() => user && handleOpenProfile(user.id)}
            className="flex items-center justify-center rounded-full glass p-2.5 text-cream/70 transition-all hover:text-cream"
          >
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="" className="h-5 w-5 rounded-full object-cover" />
            ) : (
              <User size={18} />
            )}
          </button>

          {/* Create button */}
          <button
            onClick={() => handleOpenCreate()}
            className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-gold-300 px-4 py-2 text-sm font-bold text-charcoal transition-all hover:shadow-[0_0_20px_-6px_rgba(212,169,90,0.4)]"
          >
            <Plus size={16} />
            <span className="hidden sm:inline">Create</span>
          </button>
        </div>
      </header>

      {/* Tabs */}
      {view === 'reel' && (
        <div className="absolute left-1/2 top-16 z-30 -translate-x-1/2">
          <div className="flex gap-1 rounded-full glass p-1">
            <TabButton active={tab === 'quotes'} onClick={() => setTab('quotes')} icon={<Quote size={14} />} label="Quotes" />
            <TabButton active={tab === 'reviews'} onClick={() => setTab('reviews')} icon={<Star size={14} />} label="Reviews" />
          </div>
        </div>
      )}

      {/* Reel view */}
      {view === 'reel' && (
        <div className="relative z-10 h-full w-full pt-24 pb-6">
          {postsLoading ? (
            <div className="flex h-full items-center justify-center">
              <p className="font-serif text-lg text-cream/40 animate-pulse">Loading feed...</p>
            </div>
          ) : postsError ? (
            <div className="flex h-full flex-col items-center justify-center gap-4">
              <p className="font-serif text-lg text-rose-50">{postsError}</p>
              <button onClick={loadPosts} className="rounded-full glass-light px-5 py-2.5 text-sm text-cream/70 hover:text-cream">Try again</button>
            </div>
          ) : feedPosts.length === 0 ? (
            <div className="flex h-full items-center justify-center">
              <div className="flex flex-col items-center gap-3">
                <p className="font-serif text-lg text-cream/40">No posts yet.</p>
                {user && (
                  <button
                    onClick={() => handleOpenCreate()}
                    className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-gold-300 px-5 py-2.5 text-sm font-bold text-charcoal"
                  >
                    <Plus size={16} /> Be the first to share
                  </button>
                )}
              </div>
            </div>
          ) : (
            <ReelFeed
              key={tab}
              posts={feedPosts}
              books={feedBooks}
              onOpenBook={(book) => openBook(book)}
              onToggleLike={handleToggleLike}
              onToggleSave={handleToggleSave}
              onOpenComments={(p) => {
                const source = tab === 'quotes' ? quotePosts : reviewPosts;
                const post = source.find((pp) => pp.id === p.id);
                if (post) handleOpenComments(post);
              }}
            />
          )}
        </div>
      )}

      {/* Book page */}
      {view === 'book' && activeBook && (
        <BookPage book={activeBook} onBack={backToReel} onCreatePost={(b) => handleOpenCreate(b)} />
      )}

      {/* Profile page */}
      {view === 'profile' && profileUserId && (
        <ProfilePage
          userId={profileUserId}
          onBack={() => setView('reel')}
          onOpenBook={openBookById}
          onToggleLike={(post) => handleToggleLike(post.id)}
          onToggleSave={(post) => handleToggleSave(post.id)}
          onOpenComments={(post) => handleOpenComments(post)}
          onMessage={handleMessageUser}
        />
      )}

      {/* Messages */}
      {view === 'messages' && (
        <MessagesScreen
          conversationId={activeConversation}
          preselectedUserId={messagePreselect}
          onBack={() => setView('reel')}
          onOpenConversation={(id) => setActiveConversation(id)}
          onClearPreselect={() => setMessagePreselect(null)}
          sharedPost={sharedPostForMessage}
          onClearSharedPost={() => setSharedPostForMessage(null)}
        />
      )}

      {/* Notifications */}
      {view === 'notifications' && (
        <NotificationsScreen
          onBack={() => setView('reel')}
          onOpenProfile={handleOpenProfile}
        />
      )}

      {/* Search */}
      {view === 'search' && (
        <SearchScreen
          onBack={() => setView('reel')}
          onOpenProfile={handleOpenProfile}
          onOpenBook={openBookById}
        />
      )}

      {/* Create post modal */}
      {createOpen && (
        <CreatePostModal
          books={BOOKS}
          preselectedBook={createPreselect}
          onClose={() => {
            setCreateOpen(false);
            setCreatePreselect(null);
          }}
          onPublish={handlePublishPost}
        />
      )}

      {/* Comment drawer */}
      {commentPost && (
        <CommentDrawer
          post={commentPost}
          onClose={() => setCommentPost(null)}
          onRequireAuth={() => setAuthPrompt(true)}
        />
      )}

      {/* Swipe hint (first load) */}
      {view === 'reel' && <SwipeHint />}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-full px-5 py-2 text-sm font-medium transition-all duration-300 ${
        active
          ? 'bg-cream text-charcoal tab-glow'
          : 'text-cream/60 hover:text-cream hover:bg-cream/5'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function SwipeHint() {
  const [show, setShow] = useState(true);
  if (!show) return null;
  return (
    <div
      className="pointer-events-none absolute bottom-6 left-1/2 z-20 -translate-x-1/2 animate-fade-in"
      onAnimationEnd={() => setTimeout(() => setShow(false), 3500)}
    >
      <div className="flex items-center gap-2 rounded-full glass px-4 py-2 text-xs text-cream/50">
        <span>Swipe left or right</span>
        <span className="animate-pulse">←→</span>
      </div>
    </div>
  );
}
