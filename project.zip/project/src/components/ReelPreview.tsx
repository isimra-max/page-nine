import { Music } from 'lucide-react';
import type { Post, Book } from '@/data';
import { StarRating } from './StarRating';
import { useGoogleBookCover } from '@/hooks/useGoogleBookCover';
import { PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface ReelPreviewProps {
  type: 'quote' | 'review';
  book: Book | null;
  text: string;
  rating: number;
  songTitle: string;
  coverOverride?: string;
}

export function ReelPreview({ type, book, text, rating, songTitle, coverOverride }: ReelPreviewProps) {
  const fetched = useGoogleBookCover(book?.title ?? '', book?.coverUrl ?? '');
  const coverUrl = coverOverride || fetched.coverUrl || book?.coverUrl || PLACEHOLDER_COVER;

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden rounded-2xl glass border border-cream/8 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.8)]">
      {/* Cover hero */}
      <div className="relative h-[40%] w-full shrink-0 overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at 50% 60%, rgba(212,169,90,0.25), transparent 60%), radial-gradient(ellipse at 50% 100%, rgba(182,124,138,0.12), transparent 50%)',
          }}
        />
        <img
          src={coverUrl}
          alt={book?.title ?? 'Book preview'}
          onError={(e) => {
            const img = e.currentTarget;
            if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER;
          }}
          className="absolute left-1/2 top-1/2 h-[150%] w-auto max-w-none -translate-x-1/2 -translate-y-1/2 object-cover opacity-90"
          style={{ filter: 'saturate(1.05) contrast(1.02)' }}
        />
        <div className="absolute inset-0 vignette" />
        <div className="absolute inset-0 grain" />
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-charcoal via-charcoal/80 to-transparent" />
        <span
          className={`absolute left-4 top-4 rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-widest backdrop-blur-md ${
            type === 'quote' ? 'bg-rose/25 text-rose-50' : 'bg-gold/25 text-gold-50'
          }`}
        >
          {type}
        </span>
      </div>

      {/* Content */}
      <div className="relative flex flex-1 flex-col gap-3 px-5 pb-4 pt-2">
        <blockquote className="font-serif text-base leading-relaxed text-cream/95">
          {text || (type === 'quote' ? 'Your quote will appear here...' : 'Your review will appear here...')}
        </blockquote>

        {type === 'review' && rating > 0 && (
          <div className="flex items-center gap-2">
            <StarRating rating={rating} size={14} />
            <span className="text-xs text-cream/50">{rating}.0</span>
          </div>
        )}

        {book && (
          <div className="w-fit">
            <p className="font-serif text-sm font-medium text-cream/70">{book.title}</p>
            <p className="text-xs text-cream/40">by {book.author}</p>
          </div>
        )}

        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-rose to-rose-400 text-[10px] font-bold text-charcoal">
            Y
          </div>
          <span className="text-sm font-medium text-cream/70">@you</span>
        </div>

        <div className="flex items-center gap-2 rounded-full glass-light px-3 py-1.5 w-fit">
          <Music size={13} className="text-rose-50 animate-pulse" />
          <span className="text-xs text-cream/60">{songTitle || 'No song selected'}</span>
        </div>

        <div className="flex-1" />

        <div className="flex items-center gap-5 opacity-50">
          <div className="flex flex-col items-center gap-1">
            <span className="text-lg text-cream/70">♥</span>
            <span className="text-xs text-cream/50">0</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <span className="text-lg text-cream/70">💬</span>
            <span className="text-xs text-cream/50">0</span>
          </div>
        </div>
      </div>
    </div>
  );
}
