import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Settings, UserPlus, UserCheck, Bookmark, Heart, BookOpen, Library } from 'lucide-react';
import type { Profile } from '@/lib/supabase';
import type { PostWithMeta } from '@/lib/social';
import {
  fetchProfile, fetchPostsByUser, fetchLikedPosts, fetchSavedPosts,
  fetchFollowerCount, fetchFollowingCount, isFollowing, toggleFollow,
  fetchTbr, updateProfile,
} from '@/lib/social';
import { useAuth } from '@/hooks/useAuth';
import { ReelCard } from './ReelCard';
import { PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface ProfilePageProps {
  userId: string;
  onBack: () => void;
  onOpenBook: (bookId: string, title: string, author: string, cover: string) => void;
  onToggleLike: (post: PostWithMeta) => void;
  onToggleSave: (post: PostWithMeta) => void;
  onOpenComments: (post: PostWithMeta) => void;
  onMessage: (userId: string) => void;
}

type Tab = 'posts' | 'saved' | 'liked' | 'tbr';
type TbrStatus = 'want' | 'reading' | 'read';

export function ProfilePage({ userId, onBack, onOpenBook, onToggleLike, onToggleSave, onOpenComments, onMessage }: ProfilePageProps) {
  const { user, profile: myProfile } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [tab, setTab] = useState<Tab>('posts');
  const [posts, setPosts] = useState<PostWithMeta[]>([]);
  const [tbr, setTbr] = useState<{ id: string; book_title: string; book_author: string; book_cover: string; status: TbrStatus }[]>([]);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [following, setFollowing] = useState(false);
  const [postCount, setPostCount] = useState(0);
  const [editing, setEditing] = useState(false);
  const [editUsername, setEditUsername] = useState('');
  const [editDisplay, setEditDisplay] = useState('');
  const [editBio, setEditBio] = useState('');

  const isOwnProfile = user?.id === userId;

  const load = useCallback(async () => {
    const p = await fetchProfile(userId);
    setProfile(p);
    if (p) {
      setEditUsername(p.username);
      setEditDisplay(p.display_name ?? '');
      setEditBio(p.bio ?? '');
    }
    const [fc, fic, ps] = await Promise.all([
      fetchFollowerCount(userId),
      fetchFollowingCount(userId),
      fetchPostsByUser(userId),
    ]);
    setFollowerCount(fc);
    setFollowingCount(fic);
    setPosts(ps);
    setPostCount(ps.length);
    if (user && !isOwnProfile) {
      setFollowing(await isFollowing(user.id, userId));
    }
  }, [userId, user, isOwnProfile]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (tab === 'posts') {
      fetchPostsByUser(userId).then(setPosts);
    } else if (tab === 'liked' && isOwnProfile) {
      fetchLikedPosts(userId).then(setPosts);
    } else if (tab === 'saved' && isOwnProfile) {
      fetchSavedPosts(userId).then(setPosts);
    } else if (tab === 'tbr') {
      fetchTbr(userId).then(setTbr);
    }
  }, [tab, userId, isOwnProfile]);

  const handleFollow = async () => {
    if (!user) return;
    await toggleFollow(user.id, userId, following);
    setFollowing(!following);
    setFollowerCount(following ? followerCount - 1 : followerCount + 1);
  };

  const handleSaveEdit = async () => {
    if (!user) return;
    const { data } = await updateProfile(user.id, {
      username: editUsername,
      display_name: editDisplay,
      bio: editBio,
    });
    if (data) setProfile(data);
    setEditing(false);
    load();
  };

  const tabs: { key: Tab; label: string; icon: React.ReactNode; private?: boolean }[] = [
    { key: 'posts', label: 'Posts', icon: <BookOpen size={14} /> },
    { key: 'saved', label: 'Saved', icon: <Bookmark size={14} />, private: true },
    { key: 'liked', label: 'Liked', icon: <Heart size={14} />, private: true },
    { key: 'tbr', label: 'TBR', icon: <Library size={14} /> },
  ];

  const visibleTabs = tabs.filter((t) => !t.private || isOwnProfile);

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto animate-fade-in">
      <div
        className="pointer-events-none fixed inset-0 opacity-50 blur-3xl"
        style={{
          background: `radial-gradient(circle at 50% 20%, rgba(212,169,90,0.15), transparent 50%), radial-gradient(circle at 80% 60%, rgba(182,124,138,0.12), transparent 50%)`,
        }}
      />

      <div className="relative mx-auto flex min-h-full max-w-3xl flex-col px-6 py-6 sm:px-8 sm:py-10">
        {/* Back */}
        <button
          onClick={onBack}
          className="group mb-6 flex w-fit items-center gap-2 rounded-full glass px-4 py-2 text-sm text-cream/70 transition-colors hover:text-cream"
        >
          <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-0.5" />
          Back
        </button>

        {/* Profile header */}
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start sm:gap-8">
          {/* Avatar */}
          <div className="relative shrink-0 animate-scale-in">
            <div className="absolute -inset-3 rounded-full bg-gradient-to-br from-gold/25 via-transparent to-rose/25 opacity-70 blur-2xl" />
            <div className="relative flex h-28 w-28 items-center justify-center overflow-hidden rounded-full glass border border-cream/10">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.username} className="h-full w-full object-cover" />
              ) : (
                <span className="font-serif text-4xl font-semibold text-gold">
                  {(profile?.username?.[0] ?? '?').toUpperCase()}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-1 flex-col gap-3 pt-2 animate-slide-up">
            {editing ? (
              <div className="flex flex-col gap-2">
                <input
                  value={editDisplay}
                  onChange={(e) => setEditDisplay(e.target.value)}
                  placeholder="Display name"
                  className="rounded-full glass-light px-4 py-2 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-gold/40"
                />
                <input
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value)}
                  placeholder="Username"
                  className="rounded-full glass-light px-4 py-2 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-gold/40"
                />
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Bio"
                  rows={2}
                  className="resize-none rounded-2xl glass-light px-4 py-2 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-gold/40"
                />
                <button
                  onClick={handleSaveEdit}
                  className="w-fit rounded-full bg-gold px-5 py-2 text-sm font-semibold text-charcoal hover:bg-gold-50"
                >
                  Save
                </button>
              </div>
            ) : (
              <>
                <h1 className="font-serif text-2xl font-medium text-cream">
                  {profile?.display_name || profile?.username || 'Reader'}
                </h1>
                <p className="text-sm text-cream/40">@{profile?.username}</p>
                {profile?.bio && <p className="text-sm text-cream/60">{profile.bio}</p>}
              </>
            )}

            {/* Stats */}
            <div className="flex gap-6">
              <div>
                <span className="font-serif text-lg font-semibold text-cream">{postCount}</span>
                <span className="ml-1 text-xs text-cream/40">posts</span>
              </div>
              <div>
                <span className="font-serif text-lg font-semibold text-cream">{followerCount}</span>
                <span className="ml-1 text-xs text-cream/40">followers</span>
              </div>
              <div>
                <span className="font-serif text-lg font-semibold text-cream">{followingCount}</span>
                <span className="ml-1 text-xs text-cream/40">following</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              {isOwnProfile ? (
                <button
                  onClick={() => setEditing(!editing)}
                  className="flex items-center gap-1.5 rounded-full glass-light px-4 py-2 text-sm font-medium text-cream/70 transition-all hover:text-cream"
                >
                  <Settings size={14} />
                  Edit Profile
                </button>
              ) : (
                <>
                  <button
                    onClick={handleFollow}
                    className={`flex items-center gap-1.5 rounded-full px-5 py-2 text-sm font-semibold transition-all ${
                      following
                        ? 'glass-light text-cream/70'
                        : 'bg-rose text-charcoal hover:bg-rose-50'
                    }`}
                  >
                    {following ? <UserCheck size={14} /> : <UserPlus size={14} />}
                    {following ? 'Following' : 'Follow'}
                  </button>
                  <button
                    onClick={() => onMessage(userId)}
                    className="flex items-center gap-1.5 rounded-full glass-light px-4 py-2 text-sm font-medium text-cream/70 transition-all hover:text-cream"
                  >
                    Message
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 flex gap-1 rounded-full glass p-1 w-fit">
          {visibleTabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-all ${
                tab === t.key ? 'bg-cream text-charcoal' : 'text-cream/60 hover:text-cream'
              }`}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="mt-6">
          {tab === 'tbr' ? (
            <div className="flex flex-col gap-4">
              {(['want', 'reading', 'read'] as TbrStatus[]).map((status) => {
                const items = tbr.filter((t) => t.status === status);
                if (items.length === 0) return null;
                return (
                  <div key={status}>
                    <h3 className="mb-3 font-serif text-lg font-medium text-cream/80 capitalize">
                      {status === 'want' ? 'Want to Read' : status === 'reading' ? 'Currently Reading' : 'Read'}
                    </h3>
                    <div className="flex gap-3 overflow-x-auto no-scrollbar">
                      {items.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => onOpenBook('', item.book_title, item.book_author, item.book_cover)}
                          className="group shrink-0"
                        >
                          <img
                            src={item.book_cover || PLACEHOLDER_COVER}
                            alt={item.book_title}
                            onError={(e) => { const img = e.currentTarget; if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER; }}
                            className="h-32 w-22 rounded-lg object-cover ring-1 ring-cream/10 transition-all group-hover:ring-gold/50 group-hover:scale-105"
                            style={{ aspectRatio: '2/3' }}
                          />
                          <p className="mt-1 max-w-22 truncate text-[10px] text-cream/50">{item.book_title}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
              {tbr.length === 0 && (
                <p className="py-8 text-center text-sm text-cream/40">No books in your TBR yet.</p>
              )}
            </div>
          ) : posts.length === 0 ? (
            <p className="py-12 text-center text-sm text-cream/40">
              {tab === 'posts' ? 'No posts yet.' : tab === 'liked' ? 'No liked posts.' : 'No saved posts.'}
            </p>
          ) : (
            <div className="flex flex-col gap-4">
              {posts.map((post) => (
                <div key={post.id} className="h-[400px]">
                  <ReelCard
                    post={{
                      id: post.id,
                      type: post.type,
                      bookId: post.book_id,
                      text: post.text,
                      username: post.author?.username ?? 'unknown',
                      rating: post.rating || undefined,
                      songTitle: post.song_title,
                      audioUrl: post.audio_url || undefined,
                      audioSource: (post.audio_source as 'library' | 'upload') || undefined,
                      audioTrimStart: post.audio_trim_start || undefined,
                      audioTrimEnd: post.audio_trim_end || undefined,
                      likes: post.likeCount,
                      liked: post.liked,
                      saved: post.saved,
                      comments: [],
                      createdAt: post.created_at.slice(0, 10),
                    }}
                    book={{
                      id: post.book_id,
                      title: post.book_title,
                      author: post.book_author,
                      coverUrl: post.book_cover,
                      synopsis: '',
                      averageRating: 0,
                    }}
                    isActive={false}
                    isPlaying={false}
                    onOpenBook={() => onOpenBook(post.book_id, post.book_title, post.book_author, post.book_cover)}
                    onToggleLike={() => onToggleLike(post)}
                    onToggleSave={() => onToggleSave(post)}
                    onOpenComments={() => onOpenComments(post)}
                    onTogglePlayPause={() => {}}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="h-10" />
      </div>
    </div>
  );
}
