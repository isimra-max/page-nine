import { X, Search, Send, Quote, Star, Music, Upload, Play, Pause, Scissors, Library } from 'lucide-react';
import type { Book, Post, PostType, AudioSource } from '@/data';
import { LIBRARY_TRACKS } from '@/data';
import { useState, useRef, useEffect, useCallback } from 'react';
import { StarRating } from './StarRating';
import { ReelPreview } from './ReelPreview';
import { useGoogleBookCover, PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface CreatePostModalProps {
  books: Book[];
  preselectedBook?: Book | null;
  onClose: () => void;
  onPublish: (post: {
    type: PostType;
    bookId: string;
    text: string;
    rating?: number;
    songTitle: string;
    audioUrl?: string;
    audioSource?: AudioSource;
    audioTrimStart?: number;
    audioTrimEnd?: number;
    bookTitle: string;
    bookAuthor: string;
    bookCover: string;
  }) => void;
}

interface GoogleBookResult {
  id: string;
  volumeInfo: {
    title: string;
    authors?: string[];
    imageLinks?: {
      thumbnail?: string;
      large?: string;
      medium?: string;
      smallThumbnail?: string;
    };
    description?: string;
    averageRating?: number;
  };
}

function toBook(item: GoogleBookResult): Book {
  const links = item.volumeInfo.imageLinks;
  let coverUrl = PLACEHOLDER_COVER;
  if (links) {
    const raw = links.thumbnail || links.large || links.medium || links.smallThumbnail;
    if (raw) coverUrl = raw.replace(/^http:\/\//, 'https://').replace('&edge=curl', '');
  }
  return {
    id: item.id,
    title: item.volumeInfo.title,
    author: item.volumeInfo.authors?.[0] ?? 'Unknown',
    coverUrl,
    synopsis: item.volumeInfo.description ?? '',
    averageRating: item.volumeInfo.averageRating ?? 0,
  };
}

const MIN_TRIM = 15;
const MAX_TRIM = 30;

export function CreatePostModal({ books, preselectedBook, onClose, onPublish }: CreatePostModalProps) {
  const [type, setType] = useState<PostType>('quote');
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<Book[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | null>(preselectedBook ?? null);
  const [text, setText] = useState('');
  const [rating, setRating] = useState(0);
  const [songTitle, setSongTitle] = useState('');

  const [audioSource, setAudioSource] = useState<AudioSource | null>(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [audioFileName, setAudioFileName] = useState('');
  const [audioDuration, setAudioDuration] = useState(0);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(MAX_TRIM);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);

  const [showLibrary, setShowLibrary] = useState(false);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const searchTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const coverFetched = useGoogleBookCover(selectedBook?.title ?? '', selectedBook?.coverUrl ?? '');

  // Google Books search with debounce
  useEffect(() => {
    if (!search.trim()) {
      setSearchResults(books.slice(0, 6));
      return;
    }

    setSearching(true);
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);

    searchTimerRef.current = window.setTimeout(async () => {
      try {
        const olRes = await fetch(
          `https://openlibrary.org/search.json?title=${encodeURIComponent(search)}&limit=8`
        );
        const olData = await olRes.json();
        const olResults: Book[] = (olData.docs || [])
          .filter((d: { cover_i?: number }) => d.cover_i)
          .slice(0, 8)
          .map((d: { key: string; title: string; author_name?: string[]; cover_i: number }, i: number) => ({
            id: d.key || `ol-${i}`,
            title: d.title,
            author: d.author_name?.[0] ?? 'Unknown',
            coverUrl: `https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`,
            synopsis: '',
            averageRating: 0,
          }));

        if (olResults.length > 0) {
          setSearchResults(olResults);
          setSearching(false);
          return;
        }

        const res = await fetch(
          `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(search)}&maxResults=8`
        );
        if (!res.ok) {
          setSearchResults([]);
          setSearching(false);
          return;
        }
        const data = await res.json();
        if (data.totalItems > 0) {
          setSearchResults(data.items.map(toBook));
        } else {
          setSearchResults([]);
        }
      } catch {
        setSearchResults([]);
      }
      setSearching(false);
    }, 400);

    return () => {
      if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    };
  }, [search, books]);

  // Preview audio setup
  useEffect(() => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
      setIsPreviewPlaying(false);
    }
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.preload = 'auto';
      audio.loop = true;
      previewAudioRef.current = audio;

      audio.addEventListener('loadedmetadata', () => {
        setAudioDuration(audio.duration);
        if (audio.duration < MAX_TRIM) {
          setTrimEnd(Math.max(MIN_TRIM, audio.duration));
        } else {
          setTrimEnd(MAX_TRIM);
        }
      });

      audio.addEventListener('ended', () => {
        audio.currentTime = trimStart;
        audio.play();
      });
    }
    return () => {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        previewAudioRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioUrl]);

  const togglePreviewPlay = useCallback(() => {
    const audio = previewAudioRef.current;
    if (!audio) return;

    if (isPreviewPlaying) {
      audio.pause();
      setIsPreviewPlaying(false);
    } else {
      audio.currentTime = trimStart;
      audio.play().then(() => setIsPreviewPlaying(true)).catch(() => {});
    }
  }, [isPreviewPlaying, trimStart]);

  // Loop trim enforcement for preview
  useEffect(() => {
    const audio = previewAudioRef.current;
    if (!audio || !isPreviewPlaying) return;
    const onTimeUpdate = () => {
      if (audio.currentTime >= trimEnd) {
        audio.currentTime = trimStart;
      }
    };
    audio.addEventListener('timeupdate', onTimeUpdate);
    return () => audio.removeEventListener('timeupdate', onTimeUpdate);
  }, [isPreviewPlaying, trimStart, trimEnd]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setAudioUrl(url);
    setAudioSource('upload');
    setAudioFileName(file.name);
    const nameWithoutExt = file.name.replace(/\.[^.]+$/, '');
    if (!songTitle) setSongTitle(nameWithoutExt);
  };

  const selectLibraryTrack = (trackId: string) => {
    const track = LIBRARY_TRACKS.find((t) => t.id === trackId);
    if (!track) return;
    setAudioUrl(track.url);
    setAudioSource('library');
    setAudioFileName(track.title);
    setSongTitle(track.title);
  };

  const canPublish = selectedBook && text.trim() && (type === 'quote' || rating > 0);

  const handlePublish = () => {
    if (!canPublish || !selectedBook) return;
    onPublish({
      type,
      bookId: selectedBook.id,
      text: text.trim(),
      rating: type === 'review' ? rating : undefined,
      songTitle: songTitle.trim() || 'No song selected',
      audioUrl: audioUrl || undefined,
      audioSource: audioSource || undefined,
      audioTrimStart: audioSource ? trimStart : undefined,
      audioTrimEnd: audioSource ? trimEnd : undefined,
      bookTitle: selectedBook.title,
      bookAuthor: selectedBook.author,
      bookCover: coverFetched.coverUrl || selectedBook.coverUrl,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex animate-fade-in items-end justify-center sm:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-charcoal/80 backdrop-blur-md" />
      <div
        className="relative flex max-h-[92vh] w-full max-w-3xl flex-col rounded-t-3xl glass border-t border-cream/10 sm:rounded-3xl sm:border animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cream/10 px-5 py-4">
          <h3 className="font-serif text-lg font-medium text-cream">Create Post</h3>
          <button onClick={onClose} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
            <X size={20} />
          </button>
        </div>

        <div className="flex flex-1 flex-col overflow-hidden lg:flex-row">
          {/* Left: form */}
          <div className="flex-1 overflow-y-auto px-5 py-5">
            {/* Type toggle */}
            <div className="mb-5 flex gap-2 rounded-full glass-light p-1">
              {(['quote', 'review'] as PostType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  className={`flex flex-1 items-center justify-center gap-1.5 rounded-full py-2.5 text-sm font-medium capitalize transition-all ${
                    type === t ? 'bg-rose text-charcoal' : 'text-cream/60 hover:text-cream'
                  }`}
                >
                  {t === 'quote' ? <Quote size={15} /> : <Star size={15} />}
                  {t}
                </button>
              ))}
            </div>

            {/* Book search */}
            <label className="mb-2 block text-xs font-semibold uppercase tracking-widest text-cream/40">
              Search Book
            </label>
            {selectedBook ? (
              <div className="mb-3 flex items-center gap-3 rounded-2xl glass-light p-3 animate-fade-in">
                <img src={coverFetched.coverUrl || selectedBook.coverUrl} alt={selectedBook.title} onError={(e) => { const img = e.currentTarget; if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER; }} className="h-16 w-11 rounded-md object-cover" />
                <div className="flex-1">
                  <p className="font-serif text-sm font-medium text-cream">{selectedBook.title}</p>
                  <p className="text-xs text-cream/40">{selectedBook.author}</p>
                </div>
                <button
                  onClick={() => setSelectedBook(null)}
                  className="rounded-full p-1 text-cream/40 transition-colors hover:bg-cream/10 hover:text-cream"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <>
                <div className="mb-3 flex items-center gap-2 rounded-full glass-light px-4 py-2.5">
                  <Search size={16} className="text-cream/40" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by title or author..."
                    className="flex-1 bg-transparent text-sm text-cream placeholder-cream/30 outline-none"
                  />
                  {searching && <span className="text-xs text-cream/30">...</span>}
                </div>
                <div className="mb-5 flex gap-2 overflow-x-auto no-scrollbar">
                  {searchResults.length === 0 && !searching && (
                    <p className="text-xs text-cream/30 py-4">No results found.</p>
                  )}
                  {searchResults.map((b) => (
                    <button
                      key={b.id}
                      onClick={() => setSelectedBook(b)}
                      className="group shrink-0"
                    >
                      <img
                        src={b.coverUrl}
                        alt={b.title}
                        onError={(e) => { const img = e.currentTarget; if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER; }}
                        className="h-24 w-16 rounded-lg object-cover ring-1 ring-cream/10 transition-all group-hover:ring-rose/50 group-hover:scale-105"
                      />
                      <p className="mt-1 max-w-16 truncate text-[10px] text-cream/50">{b.title}</p>
                    </button>
                  ))}
                </div>
              </>
            )}

            {/* Text */}
            <label className="mb-2 block text-xs font-semibold uppercase tracking-widest text-cream/40">
              {type === 'quote' ? 'Your Quote' : 'Your Review'}
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={type === 'quote' ? 'Write a memorable line...' : 'Share your thoughts...'}
              rows={3}
              className="mb-5 w-full resize-none rounded-2xl glass-light px-4 py-3 font-serif text-base text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-rose/40"
            />

            {/* Rating for reviews */}
            {type === 'review' && (
              <div className="mb-5 animate-fade-in">
                <label className="mb-2 block text-xs font-semibold uppercase tracking-widest text-cream/40">
                  Rating
                </label>
                <StarRating rating={rating} size={28} interactive onChange={setRating} />
              </div>
            )}

            {/* Audio section */}
            <label className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-cream/40">
              <Music size={12} /> Audio for Reel
            </label>

            {/* Audio source tabs */}
            <div className="mb-3 flex gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium transition-all ${
                  audioSource === 'upload' ? 'bg-gold text-charcoal' : 'glass-light text-cream/60 hover:text-cream'
                }`}
              >
                <Upload size={13} /> Upload
              </button>
              <button
                onClick={() => setShowLibrary(!showLibrary)}
                className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium transition-all ${
                  audioSource === 'library' ? 'bg-gold text-charcoal' : 'glass-light text-cream/60 hover:text-cream'
                }`}
              >
                <Library size={13} /> Library
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/mpeg,audio/mp3,audio/m4a,audio/wav,audio/x-m4a"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Library tracks */}
            {showLibrary && (
              <div className="mb-3 flex gap-2 overflow-x-auto no-scrollbar animate-fade-in">
                {LIBRARY_TRACKS.map((track) => (
                  <button
                    key={track.id}
                    onClick={() => selectLibraryTrack(track.id)}
                    className={`shrink-0 rounded-xl px-3 py-2 text-left transition-all ${
                      audioUrl === track.url ? 'bg-rose/20 ring-1 ring-rose/50' : 'glass-light hover:bg-cream/5'
                    }`}
                  >
                    <p className="max-w-32 truncate text-xs font-medium text-cream/80">{track.title}</p>
                  </button>
                ))}
              </div>
            )}

            {/* Selected audio info + trim controls */}
            {audioUrl && (
              <div className="mb-5 rounded-2xl glass-light p-3 animate-fade-in">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={togglePreviewPlay}
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-rose text-charcoal transition-all hover:bg-rose-50"
                    >
                      {isPreviewPlaying ? <Pause size={14} /> : <Play size={14} />}
                    </button>
                    <span className="text-xs text-cream/70">{audioFileName}</span>
                  </div>
                  <button
                    onClick={() => {
                      setAudioUrl('');
                      setAudioSource(null);
                      setAudioFileName('');
                      setIsPreviewPlaying(false);
                    }}
                    className="rounded-full p-1 text-cream/40 transition-colors hover:bg-cream/10 hover:text-cream"
                  >
                    <X size={14} />
                  </button>
                </div>

                {/* Trim controls */}
                <div className="flex items-center gap-2">
                  <Scissors size={12} className="text-cream/40" />
                  <span className="text-[10px] uppercase tracking-widest text-cream/40">Trim</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 text-xs text-cream/60">
                      <span>{trimStart.toFixed(0)}s</span>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0, audioDuration - MIN_TRIM)}
                        step={1}
                        value={trimStart}
                        onChange={(e) => {
                          const newStart = Number(e.target.value);
                          setTrimStart(newStart);
                          if (newStart + MIN_TRIM > trimEnd) {
                            setTrimEnd(Math.min(audioDuration || MAX_TRIM, newStart + MAX_TRIM));
                          }
                        }}
                        className="flex-1 accent-rose"
                      />
                      <span>{trimEnd.toFixed(0)}s</span>
                    </div>
                    <div className="mt-1 text-[10px] text-cream/30">
                      Clip length: {(trimEnd - trimStart).toFixed(0)}s (15-30s)
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Song title */}
            <label className="mb-2 block text-xs font-semibold uppercase tracking-widest text-cream/40">
              Song Title
            </label>
            <input
              value={songTitle}
              onChange={(e) => setSongTitle(e.target.value)}
              placeholder="Song title — Artist"
              className="mb-5 w-full rounded-full glass-light px-4 py-2.5 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-rose/40"
            />
          </div>

          {/* Right: live preview */}
          <div className="hidden border-l border-cream/10 p-5 lg:block lg:w-[280px]">
            <label className="mb-3 block text-xs font-semibold uppercase tracking-widest text-cream/40">
              Live Preview
            </label>
            <div className="h-[420px] w-full">
              <ReelPreview
                type={type}
                book={selectedBook}
                text={text}
                rating={rating}
                songTitle={songTitle}
                coverOverride={coverFetched.coverUrl || selectedBook?.coverUrl}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-cream/10 p-4">
          <button
            onClick={handlePublish}
            disabled={!canPublish}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold to-gold-300 py-3 text-sm font-bold text-charcoal transition-all hover:shadow-[0_0_24px_-6px_rgba(212,169,90,0.6)] disabled:opacity-30 disabled:shadow-none"
          >
            <Send size={16} />
            Publish
          </button>
        </div>
      </div>
    </div>
  );
}
