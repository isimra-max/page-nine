import { X, Send, ArrowLeft } from 'lucide-react';
import type { PostWithMeta } from '@/lib/social';
import { fetchComments, addComment } from '@/lib/social';
import type { CommentRow } from '@/lib/supabase';
import type { Profile } from '@/lib/supabase';
import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';

interface CommentDrawerProps {
  post: PostWithMeta;
  onClose: () => void;
  onRequireAuth: () => void;
}

interface CommentWithAuthor extends CommentRow {
  author: Profile | null;
  replies: CommentWithAuthor[];
}

export function CommentDrawer({ post, onClose, onRequireAuth }: CommentDrawerProps) {
  const { user } = useAuth();
  const [comments, setComments] = useState<CommentWithAuthor[]>([]);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const loadComments = useCallback(async () => {
    const fetched = await fetchComments(post.id);
    const map = new Map<string, CommentWithAuthor>();
    const roots: CommentWithAuthor[] = [];

    fetched.forEach((c) => {
      map.set(c.id, { ...c, replies: [] });
    });

    fetched.forEach((c) => {
      const node = map.get(c.id)!;
      if (c.parent_id && map.has(c.parent_id)) {
        map.get(c.parent_id)!.replies.push(node);
      } else {
        roots.push(node);
      }
    });

    setComments(roots);
  }, [post.id]);

  useEffect(() => { loadComments(); }, [loadComments]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    if (!user) { onRequireAuth(); return; }
    await addComment(post.id, user.id, text.trim());
    setText('');
    loadComments();
  };

  const submitReply = async (parentId: string) => {
    if (!replyText.trim()) return;
    if (!user) { onRequireAuth(); return; }
    await addComment(post.id, user.id, replyText.trim(), parentId);
    setReplyText('');
    setReplyTo(null);
    loadComments();
  };

  const renderComment = (c: CommentWithAuthor, isReply = false) => (
    <div key={c.id} className={`flex gap-3 animate-fade-in ${isReply ? 'ml-11' : ''}`}>
      <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full glass">
        {c.author?.avatar_url ? (
          <img src={c.author.avatar_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="text-xs font-bold text-gold">{(c.author?.username?.[0] ?? '?').toUpperCase()}</span>
        )}
      </div>
      <div className="flex-1">
        <p className="text-xs font-medium text-cream/60">@{c.author?.username ?? 'unknown'}</p>
        <p className="text-sm text-cream/90">{c.text}</p>
        {user && (
          <button
            onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}
            className="mt-1 text-[10px] text-cream/30 hover:text-cream/60"
          >
            Reply
          </button>
        )}
        {replyTo === c.id && (
          <div className="mt-2 flex items-center gap-2">
            <input
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submitReply(c.id)}
              placeholder={`Reply to @${c.author?.username}...`}
              className="flex-1 rounded-full glass-light px-3 py-2 text-xs text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-rose/40"
              autoFocus
            />
            <button
              onClick={() => submitReply(c.id)}
              disabled={!replyText.trim()}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-rose text-charcoal disabled:opacity-30"
            >
              <Send size={12} />
            </button>
          </div>
        )}
        {c.replies.length > 0 && (
          <div className="mt-3 flex flex-col gap-3">
            {c.replies.map((r) => renderComment(r, true))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex animate-fade-in items-end justify-center sm:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm" />
      <div
        className="relative flex max-h-[80vh] w-full max-w-md flex-col rounded-t-3xl glass border-t border-cream/10 sm:rounded-3xl sm:border animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cream/10 px-5 py-4">
          <h3 className="font-serif text-lg font-medium text-cream">Comments</h3>
          <button onClick={onClose} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
            <X size={20} />
          </button>
        </div>

        {/* Comments list */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {comments.length === 0 ? (
            <p className="py-8 text-center text-sm text-cream/40">No comments yet. Start the conversation.</p>
          ) : (
            <div className="flex flex-col gap-4">
              {comments.map((c) => renderComment(c))}
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={submit} className="flex items-center gap-2 border-t border-cream/10 p-4">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={user ? "Add a comment..." : "Sign in to comment..."}
            className="flex-1 rounded-full glass-light px-4 py-2.5 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-rose/40"
            autoFocus
          />
          <button
            type="submit"
            disabled={!text.trim()}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-rose text-charcoal transition-all hover:bg-rose-50 disabled:opacity-30"
          >
            <Send size={16} />
          </button>
        </form>
      </div>
    </div>
  );
}
