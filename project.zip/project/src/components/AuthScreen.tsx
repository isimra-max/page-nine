import { useState } from 'react';
import { BookOpen, Mail, Lock, ArrowRight } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = mode === 'signin' ? await signIn(email, password) : await signUp(email, password);
    setLoading(false);
    if (result.error) {
      setError(result.error);
    }
  };

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-charcoal">
      {/* Ambient backdrop */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 50% 0%, rgba(212,169,90,0.12), transparent 50%), radial-gradient(ellipse at 30% 100%, rgba(182,124,138,0.10), transparent 55%)',
        }}
      />
      <div className="pointer-events-none absolute inset-0 grain" />
      <div className="pointer-events-none absolute inset-0 vignette" />

      {/* Floating particles */}
      {Array.from({ length: 10 }).map((_, i) => (
        <span
          key={i}
          className="particle"
          style={{
            width: 2 + Math.random() * 4,
            height: 2 + Math.random() * 4,
            left: `${Math.random() * 100}%`,
            bottom: '-20px',
            animationDuration: `${12 + Math.random() * 18}s`,
            animationDelay: `${-Math.random() * 20}s`,
            '--drift': `${(Math.random() - 0.5) * 80}px`,
            '--p-opacity': 0.3 + Math.random() * 0.3,
          } as React.CSSProperties}
        />
      ))}

      {/* Card */}
      <div className="relative z-10 w-full max-w-sm px-6 animate-fade-in">
        <div className="flex flex-col items-center gap-2 mb-8">
          <BookOpen size={36} className="text-gold" />
          <h1 className="font-serif text-3xl font-semibold tracking-tight text-cream">
            Page <span className="text-gradient-gold">Nine</span>
          </h1>
          <p className="text-sm text-cream/40">Where readers gather</p>
        </div>

        <div className="rounded-3xl glass border border-cream/8 p-6 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.8)]">
          {/* Mode toggle */}
          <div className="mb-5 flex gap-1 rounded-full glass-light p-1">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 rounded-full py-2 text-sm font-medium transition-all ${
                mode === 'signin' ? 'bg-cream text-charcoal' : 'text-cream/60 hover:text-cream'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 rounded-full py-2 text-sm font-medium transition-all ${
                mode === 'signup' ? 'bg-cream text-charcoal' : 'text-cream/60 hover:text-cream'
              }`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-cream/40">
                Email
              </label>
              <div className="flex items-center gap-2 rounded-full glass-light px-4 py-3">
                <Mail size={16} className="text-cream/40" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="flex-1 bg-transparent text-sm text-cream placeholder-cream/30 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-cream/40">
                Password
              </label>
              <div className="flex items-center gap-2 rounded-full glass-light px-4 py-3">
                <Lock size={16} className="text-cream/40" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  required
                  minLength={6}
                  className="flex-1 bg-transparent text-sm text-cream placeholder-cream/30 outline-none"
                />
              </div>
            </div>

            {error && (
              <p className="text-xs text-rose-50 animate-fade-in">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold to-gold-300 py-3 text-sm font-bold text-charcoal transition-all hover:shadow-[0_0_24px_-6px_rgba(212,169,90,0.6)] disabled:opacity-50"
            >
              {loading ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
              {!loading && <ArrowRight size={16} />}
            </button>
          </form>

          <p className="mt-5 text-center text-xs text-cream/30">
            {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
            <button
              onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(null); }}
              className="text-gold hover:underline"
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>

        <p className="mt-6 text-center text-xs text-cream/20">
          Browse the feed freely. Sign in to like, save, comment, and post.
        </p>
      </div>
    </div>
  );
}
