import { useState, useEffect } from 'react';
import { ArrowLeft, Heart, MessageCircle, UserPlus, Share2, Mail } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { fetchNotifications, markNotificationsRead } from '@/lib/social';
import type { NotificationRow } from '@/lib/supabase';
import type { Profile } from '@/lib/supabase';

interface NotificationsScreenProps {
  onBack: () => void;
  onOpenProfile: (userId: string) => void;
}

export function NotificationsScreen({ onBack, onOpenProfile }: NotificationsScreenProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<(NotificationRow & { actor: Profile | null })[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const notifs = await fetchNotifications(user.id);
      setNotifications(notifs);
      await markNotificationsRead(user.id);
    })();
  }, [user]);

  const iconFor = (type: string) => {
    switch (type) {
      case 'like': return <Heart size={14} className="text-rose" />;
      case 'comment': return <MessageCircle size={14} className="text-gold" />;
      case 'follow': return <UserPlus size={14} className="text-rose-50" />;
      case 'share': return <Share2 size={14} className="text-cream/60" />;
      case 'message': return <Mail size={14} className="text-gold-50" />;
      default: return null;
    }
  };

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto bg-charcoal animate-fade-in">
      <div
        className="pointer-events-none fixed inset-0 opacity-30 blur-3xl"
        style={{
          background: 'radial-gradient(circle at 50% 0%, rgba(212,169,90,0.10), transparent 50%)',
        }}
      />

      <div className="relative mx-auto flex min-h-full max-w-2xl flex-col px-6 py-6">
        <div className="mb-6 flex items-center gap-3">
          <button onClick={onBack} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
            <ArrowLeft size={20} />
          </button>
          <h2 className="font-serif text-lg font-medium text-cream">Notifications</h2>
        </div>

        <div className="flex flex-col gap-2">
          {notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => n.actor_id && onOpenProfile(n.actor_id)}
              className={`flex items-center gap-3 rounded-2xl p-3 transition-all hover:bg-cream/5 ${
                !n.read ? 'glass-light' : 'opacity-60'
              }`}
            >
              <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full glass shrink-0">
                {n.actor?.avatar_url ? (
                  <img src={n.actor.avatar_url} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="text-sm font-semibold text-gold">
                    {(n.actor?.username?.[0] ?? '?').toUpperCase()}
                  </span>
                )}
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm text-cream/80">
                  <span className="font-medium text-cream">{n.actor?.display_name || n.actor?.username || 'Someone'}</span>{' '}
                  {n.text}
                </p>
                <p className="text-xs text-cream/30">{new Date(n.created_at).toLocaleDateString()}</p>
              </div>
              <div className="shrink-0">{iconFor(n.type)}</div>
            </button>
          ))}
          {notifications.length === 0 && (
            <div className="flex flex-col items-center gap-3 py-16">
              <Heart size={32} className="text-cream/20" />
              <p className="text-sm text-cream/30">No notifications yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
