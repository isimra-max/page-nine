import { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowLeft, Send, Search, MessageCircle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import type { Profile } from '@/lib/supabase';
import { searchProfiles } from '@/lib/social';
import {
  fetchConversations, fetchMessages, sendMessage, markMessagesRead, getOrCreateConversation,
  type ConversationWithOther,
} from '@/lib/messaging';
import type { MessageRow } from '@/lib/supabase';
import { PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface MessagesScreenProps {
  conversationId: string | null;
  preselectedUserId: string | null;
  onBack: () => void;
  onOpenConversation: (id: string) => void;
  onClearPreselect: () => void;
  sharedPost?: { id: string; text: string; bookTitle: string } | null;
  onClearSharedPost: () => void;
}

export function MessagesScreen({
  conversationId, preselectedUserId, onBack, onOpenConversation, onClearPreselect,
  sharedPost, onClearSharedPost,
}: MessagesScreenProps) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<ConversationWithOther[]>([]);
  const [activeConvo, setActiveConvo] = useState<ConversationWithOther | null>(null);
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [text, setText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadConversations = useCallback(async () => {
    if (!user) return;
    const convos = await fetchConversations(user.id);
    setConversations(convos);
  }, [user]);

  useEffect(() => { loadConversations(); }, [loadConversations]);

  // Handle preselected user
  useEffect(() => {
    if (preselectedUserId && user) {
      (async () => {
        const convoId = await getOrCreateConversation(user.id, preselectedUserId);
        if (convoId) {
          onClearPreselect();
          onOpenConversation(convoId);
        }
      })();
    }
  }, [preselectedUserId, user, onClearPreselect, onOpenConversation]);

  // Load active conversation messages
  useEffect(() => {
    if (!conversationId || !user) return;
    const convo = conversations.find((c) => c.id === conversationId) || null;
    setActiveConvo(convo);
    (async () => {
      const msgs = await fetchMessages(conversationId);
      setMessages(msgs);
      await markMessagesRead(conversationId, user.id);
      loadConversations();
    })();
  }, [conversationId, user, conversations, loadConversations]);

  // Search users
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    const timer = setTimeout(async () => {
      const results = await searchProfiles(searchQuery);
      setSearchResults(results.filter((p) => p.id !== user?.id));
      setSearching(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery, user]);

  const handleSend = async () => {
    if (!text.trim() || !conversationId || !user) return;
    const msgText = text.trim();
    setText('');
    await sendMessage(conversationId, user.id, msgText, sharedPost ? {
      sharedPostId: sharedPost.id,
      sharedBookTitle: sharedPost.bookTitle,
    } : undefined);
    if (sharedPost) onClearSharedPost();
    const msgs = await fetchMessages(conversationId);
    setMessages(msgs);
    loadConversations();
  };

  const handleStartConversation = async (otherUserId: string) => {
    if (!user) return;
    const convoId = await getOrCreateConversation(user.id, otherUserId);
    if (convoId) {
      setSearchQuery('');
      onOpenConversation(convoId);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="absolute inset-0 z-40 overflow-hidden bg-charcoal animate-fade-in">
      <div
        className="pointer-events-none absolute inset-0 opacity-30 blur-3xl"
        style={{
          background: 'radial-gradient(circle at 50% 0%, rgba(212,169,90,0.10), transparent 50%), radial-gradient(circle at 80% 60%, rgba(182,124,138,0.08), transparent 50%)',
        }}
      />

      {conversationId ? (
        // Conversation view
        <div className="relative flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-cream/10 px-4 py-4">
            <button onClick={onBack} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
              <ArrowLeft size={20} />
            </button>
            <div className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full glass">
              {activeConvo?.otherUser?.avatar_url ? (
                <img src={activeConvo.otherUser.avatar_url} alt="" className="h-full w-full object-cover" />
              ) : (
                <span className="text-sm font-semibold text-gold">
                  {(activeConvo?.otherUser?.username?.[0] ?? '?').toUpperCase()}
                </span>
              )}
            </div>
            <div>
              <p className="font-serif text-sm font-medium text-cream">
                {activeConvo?.otherUser?.display_name || activeConvo?.otherUser?.username || 'Chat'}
              </p>
              <p className="text-xs text-cream/40">@{activeConvo?.otherUser?.username}</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4">
            <div className="flex flex-col gap-2">
              {messages.map((msg) => {
                const isMe = msg.sender_id === user?.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
                        isMe
                          ? 'bg-gradient-to-br from-gold to-gold-300 text-charcoal'
                          : 'glass-light text-cream'
                      }`}
                    >
                      {msg.shared_post_id && (
                        <div className="mb-1.5 rounded-lg glass p-2 text-xs">
                          <p className="text-cream/60">Shared post from {msg.shared_book_title || 'a book'}</p>
                        </div>
                      )}
                      <p className="text-sm">{msg.text}</p>
                    </div>
                  </div>
                );
              })}
              {messages.length === 0 && (
                <p className="py-8 text-center text-sm text-cream/30">Start the conversation.</p>
              )}
            </div>
            <div ref={messagesEndRef} />
          </div>

          {/* Shared post indicator */}
          {sharedPost && (
            <div className="flex items-center gap-2 px-4 py-2 border-t border-cream/10 animate-fade-in">
              <div className="flex-1 rounded-lg glass-light px-3 py-2 text-xs text-cream/60">
                Sharing: {sharedPost.text.slice(0, 50)}...
              </div>
              <button onClick={onClearSharedPost} className="text-cream/40 hover:text-cream text-xs">Cancel</button>
            </div>
          )}

          {/* Input */}
          <div className="flex items-center gap-2 border-t border-cream/10 p-4">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a message..."
              className="flex-1 rounded-full glass-light px-4 py-2.5 text-sm text-cream placeholder-cream/30 outline-none focus:ring-1 focus:ring-gold/40"
              autoFocus
            />
            <button
              onClick={handleSend}
              disabled={!text.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-gold text-charcoal transition-all hover:bg-gold-50 disabled:opacity-30"
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      ) : (
        // Conversation list / new message
        <div className="relative flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-cream/10 px-4 py-4">
            <button onClick={onBack} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
              <ArrowLeft size={20} />
            </button>
            <h2 className="font-serif text-lg font-medium text-cream">Messages</h2>
          </div>

          {/* Search */}
          <div className="px-4 py-3">
            <div className="flex items-center gap-2 rounded-full glass-light px-4 py-2.5">
              <Search size={16} className="text-cream/40" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for users to message..."
                className="flex-1 bg-transparent text-sm text-cream placeholder-cream/30 outline-none"
              />
              {searching && <span className="text-xs text-cream/30">...</span>}
            </div>
          </div>

          {/* Search results or conversation list */}
          <div className="flex-1 overflow-y-auto px-4">
            {searchQuery.trim() ? (
              <div className="flex flex-col gap-2">
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleStartConversation(p.id)}
                    className="flex items-center gap-3 rounded-2xl glass-light p-3 transition-all hover:bg-cream/5"
                  >
                    <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full glass">
                      {p.avatar_url ? (
                        <img src={p.avatar_url} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <span className="text-sm font-semibold text-gold">{p.username[0].toUpperCase()}</span>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-cream">{p.display_name || p.username}</p>
                      <p className="text-xs text-cream/40">@{p.username}</p>
                    </div>
                  </button>
                ))}
                {searchResults.length === 0 && !searching && (
                  <p className="py-4 text-center text-sm text-cream/30">No users found.</p>
                )}
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {conversations.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onOpenConversation(c.id)}
                    className="flex items-center gap-3 rounded-2xl glass-light p-3 transition-all hover:bg-cream/5"
                  >
                    <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full glass">
                      {c.otherUser?.avatar_url ? (
                        <img src={c.otherUser.avatar_url} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <span className="text-sm font-semibold text-gold">
                          {(c.otherUser?.username?.[0] ?? '?').toUpperCase()}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm font-medium text-cream">{c.otherUser?.display_name || c.otherUser?.username}</p>
                      <p className="truncate text-xs text-cream/40">
                        {c.lastMessage?.text || 'No messages yet'}
                      </p>
                    </div>
                    {c.unreadCount > 0 && (
                      <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-rose px-1.5 text-[10px] font-bold text-charcoal">
                        {c.unreadCount}
                      </span>
                    )}
                  </button>
                ))}
                {conversations.length === 0 && (
                  <div className="flex flex-col items-center gap-3 py-12">
                    <MessageCircle size={32} className="text-cream/20" />
                    <p className="text-sm text-cream/30">No conversations yet. Search for users above.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
