import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  interactive?: boolean;
  onChange?: (rating: number) => void;
}

export function StarRating({ rating, size = 16, interactive = false, onChange }: StarRatingProps) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={!interactive}
          onClick={(e) => {
            e.stopPropagation();
            onChange?.(n);
          }}
          className={`${interactive ? 'cursor-pointer transition-transform hover:scale-125' : 'cursor-default'} ${
            interactive ? '' : 'pointer-events-none'
          }`}
        >
          <Star
            size={size}
            className={
              n <= Math.round(rating)
                ? 'fill-gold text-gold drop-shadow-[0_0_4px_rgba(212,169,90,0.5)]'
                : 'text-cream/20'
            }
          />
        </button>
      ))}
    </div>
  );
}
