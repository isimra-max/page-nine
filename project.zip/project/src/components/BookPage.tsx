import { ArrowLeft, BookOpen, Bookmark, Check } from 'lucide-react';
import type { Book } from '@/data';
import { StarRating } from './StarRating';
import { useState, useEffect } from 'react';
import { useGoogleBookCover, PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';
import { useAuth } from '@/hooks/useAuth';
import { fetchTbr, upsertTbr, removeTbr } from '@/lib/social';

interface BookPageProps {
  book: Book;
  onBack: () => void;
  onCreatePost: (book: Book) => void;
}

type ReadStatus = 'want' | 'reading' | 'read' | null;

export function BookPage({ book, onBack, onCreatePost }: BookPageProps) {
  const { user } = useAuth();
  const [status, setStatus] = useState<ReadStatus>(null);
  const fetched = useGoogleBookCover(book.title, book.coverUrl);
  const coverUrl = fetched.coverUrl || book.coverUrl || PLACEHOLDER_COVER;
  const synopsis = fetched.synopsis || book.synopsis;
  const avgRating = fetched.averageRating ?? (book.averageRating > 0 ? book.averageRating : undefined);
  const ratingsCount = fetched.ratingsCount;

  useEffect(() => {
    if (!user) return;
    (async () => {
      const tbr = await fetchTbr(user.id);
      const existing = tbr.find((t) => t.book_id === book.id);
      if (existing) setStatus(existing.status as ReadStatus);
    })();
  }, [user, book.id]);

  const handleStatusChange = async (newStatus: NonNullable<ReadStatus>) => {
    if (!user) return;
    const prev = status;
    setStatus(newStatus);
    if (prev === newStatus) return;
    await upsertTbr({
      user_id: user.id,
      book_id: book.id,
      book_title: book.title,
      book_author: book.author,
      book_cover: coverUrl,
      status: newStatus,
    });
  };

  const statuses: { key: NonNullable<ReadStatus>; label: string }[] = [
    { key: 'want', label: 'Want to Read' },
    { key: 'reading', label: 'Reading' },
    { key: 'read', label: 'Read' },
  ];

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto animate-fade-in">
      <div
        className="pointer-events-none fixed inset-0 opacity-50 blur-3xl"
        style={{
          background: `radial-gradient(circle at 50% 20%, rgba(212,169,90,0.15), transparent 50%), radial-gradient(circle at 80% 60%, rgba(182,124,138,0.12), transparent 50%)`,
        }}
      />

      <div className="relative mx-auto flex min-h-full max-w-3xl flex-col px-6 py-6 sm:px-8 sm:py-10">
        <button
          onClick={onBack}
          className="group mb-6 flex w-fit items-center gap-2 rounded-full glass px-4 py-2 text-sm text-cream/70 transition-colors hover:text-cream"
        >
          <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-0.5" />
          Back to reel
        </button>

        <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start sm:gap-10">
          <div className="relative shrink-0 animate-scale-in">
            <div className="absolute -inset-4 rounded-2xl bg-gradient-to-br from-gold/25 via-transparent to-rose/25 opacity-70 blur-2xl" />
            <img
              src={coverUrl}
              alt={book.title}
              onError={(e) => {
                const img = e.currentTarget;
                if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER;
              }}
              className="relative w-44 rounded-xl object-cover shadow-2xl ring-1 ring-cream/10 glow-cover sm:w-56"
              style={{ aspectRatio: '2/3' }}
            />
          </div>

          <div className="flex flex-1 flex-col gap-4 pt-2 animate-slide-up">
            <h1 className="font-serif text-3xl font-medium leading-tight text-cream sm:text-4xl">
              {book.title}
            </h1>
            <p className="text-base text-cream/50">by {book.author}</p>

            {avgRating != null && avgRating > 0 ? (
              <div className="flex items-center gap-3">
                <StarRating rating={avgRating} size={20} />
                <span className="text-sm font-medium text-cream/70">{avgRating.toFixed(1)}</span>
                {ratingsCount != null && ratingsCount > 0 && (
                  <span className="text-xs text-cream/30">{ratingsCount.toLocaleString()} rating{ratingsCount === 1 ? '' : 's'}</span>
                )}
              </div>
            ) : null}

            <div className="mt-2 flex flex-wrap gap-2">
              {statuses.map((s) => (
                <button
                  key={s.key}
                  onClick={() => handleStatusChange(s.key)}
                  className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-all ${
                    status === s.key
                      ? 'bg-gold text-charcoal shadow-[0_0_20px_-5px_rgba(212,169,90,0.6)]'
                      : 'glass-light text-cream/70 hover:text-cream'
                  }`}
                >
                  {status === s.key && <Check size={14} />}
                  {s.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => onCreatePost(book)}
              className="mt-2 flex w-fit items-center gap-2 rounded-full bg-rose px-5 py-2.5 text-sm font-semibold text-charcoal transition-all hover:bg-rose-50 hover:shadow-[0_0_24px_-6px_rgba(182,124,138,0.6)]"
            >
              <BookOpen size={16} />
              Create Post
            </button>
          </div>
        </div>

        <div className="mt-10 animate-slide-up">
          <h2 className="mb-3 font-serif text-lg font-medium text-cream/80">Synopsis</h2>
          {synopsis ? (
            <p className="font-serif text-lg leading-relaxed text-cream/70">{synopsis}</p>
          ) : (
            <p className="font-serif text-lg leading-relaxed text-cream/40 italic">Synopsis unavailable</p>
          )}
        </div>

        {status && (
          <div className="mt-8 flex items-center gap-2 rounded-2xl glass-light px-5 py-4 text-sm text-cream/60 animate-fade-in">
            <Bookmark size={16} className="fill-gold text-gold" />
            Added to your <span className="font-medium text-cream">{status === 'want' ? 'Want to Read' : status === 'reading' ? 'Currently Reading' : 'Read'}</span> shelf
          </div>
        )}

        <div className="h-10" />
      </div>
    </div>
  );
}
