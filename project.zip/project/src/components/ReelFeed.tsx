import { useRef, useEffect, useState, useCallback } from 'react';
import { Volume2, VolumeX, AlertCircle } from 'lucide-react';
import type { Post, Book } from '@/data';
import { ReelCard } from './ReelCard';
import { useAudioEngine } from '@/hooks/useAudioEngine';

interface ReelFeedProps {
  posts: Post[];
  books: Record<string, Book>;
  onOpenBook: (book: Book) => void;
  onToggleLike: (postId: string) => void;
  onToggleSave: (postId: string) => void;
  onOpenComments: (post: Post) => void;
}

export function ReelFeed({ posts, books, onOpenBook, onToggleLike, onToggleSave, onOpenComments }: ReelFeedProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const slotRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [tilt, setTilt] = useState(0);
  const {
    playTrack,
    stop,
    preload,
    togglePlayPause,
    unlock,
    isPlaying,
    isMuted,
    isAudioUnlocked,
    hasPendingTrack,
    hasLoadError,
  } = useAudioEngine();

  // Use IntersectionObserver to detect the active/centered reel
  useEffect(() => {
    const root = scrollRef.current;
    if (!root) return;

    const observer = new IntersectionObserver(
      (entries) => {
        let bestIdx = -1;
        let bestRatio = 0;
        for (const entry of entries) {
          if (entry.intersectionRatio > bestRatio) {
            bestRatio = entry.intersectionRatio;
            bestIdx = Number((entry.target as HTMLElement).dataset.index);
          }
        }
        if (bestIdx >= 0 && bestRatio > 0.5) {
          setActiveIndex(bestIdx);
        }
      },
      {
        root,
        threshold: [0, 0.25, 0.5, 0.75, 1],
      }
    );

    slotRefs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [posts]);

  // Scroll-based tilt effect
  const updateTilt = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const slotWidth = el.clientWidth * 0.86;
    const offset = el.scrollLeft / slotWidth - activeIndex;
    setTilt(Math.max(-3, Math.min(3, offset * 3)));
  }, [activeIndex]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(updateTilt);
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, [updateTilt]);

  // Autoplay audio when active post changes
  useEffect(() => {
    const activePost = posts[activeIndex];
    if (!activePost || !activePost.audioUrl) {
      stop();
      return;
    }
    playTrack({
      url: activePost.audioUrl,
      trimStart: activePost.audioTrimStart,
      trimEnd: activePost.audioTrimEnd,
      title: activePost.songTitle,
    });
  }, [activeIndex, posts, playTrack, stop]);

  // Preload adjacent tracks
  useEffect(() => {
    const next = posts[activeIndex + 1];
    const prev = posts[activeIndex - 1];
    if (next?.audioUrl) preload(next.audioUrl);
    if (prev?.audioUrl) preload(prev.audioUrl);
  }, [activeIndex, posts, preload]);

  // Stop audio when feed unmounts
  useEffect(() => {
    return () => stop();
  }, [stop]);

  // Keyboard navigation
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const handleKey = (e: KeyboardEvent) => {
      const slotWidth = el.clientWidth * 0.86;
      if (e.key === 'ArrowRight' && activeIndex < posts.length - 1) {
        el.scrollTo({ left: (activeIndex + 1) * slotWidth, behavior: 'smooth' });
      } else if (e.key === 'ArrowLeft' && activeIndex > 0) {
        el.scrollTo({ left: (activeIndex - 1) * slotWidth, behavior: 'smooth' });
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [activeIndex, posts.length]);

  if (posts.length === 0) {
    return (
      <div className="flex h-full items-center justify-center">
        <p className="font-serif text-lg text-cream/40">No posts yet. Be the first to share.</p>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      <div
        ref={scrollRef}
        className="reel-snap no-scrollbar flex h-full w-full snap-x snap-mandatory overflow-x-auto overflow-y-hidden"
      >
        {posts.map((post, i) => {
          const distance = Math.abs(i - activeIndex);
          const isActive = i === activeIndex;
          const scale = isActive ? 1 : Math.max(0.82, 1 - distance * 0.09);
          const opacity = isActive ? 1 : Math.max(0.4, 1 - distance * 0.25);
          const cardTilt = isActive ? tilt * 0.4 : 0;

          return (
            <div
              key={post.id}
              ref={(el) => { slotRefs.current[i] = el; }}
              data-index={i}
              className="reel-slot"
            >
              <div
                className="reel-card-inner"
                style={{
                  transform: `scale(${scale}) rotateY(${-cardTilt}deg)`,
                  opacity,
                }}
              >
                <ReelCard
                  post={post}
                  book={books[post.bookId]}
                  isActive={isActive}
                  isPlaying={isActive && isPlaying}
                  onOpenBook={onOpenBook}
                  onToggleLike={onToggleLike}
                  onToggleSave={onToggleSave}
                  onOpenComments={onOpenComments}
                  onTogglePlayPause={togglePlayPause}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* "Tap to turn sound on" prompt when autoplay is blocked */}
      {hasPendingTrack && !isAudioUnlocked && (
        <button
          onClick={unlock}
          className="absolute bottom-6 left-1/2 z-40 -translate-x-1/2 flex items-center gap-2 rounded-full glass px-5 py-2.5 text-sm font-medium text-cream/80 transition-all hover:text-cream hover:bg-cream/10 animate-fade-in"
        >
          <Volume2 size={16} className="text-gold" />
          Tap to turn sound on
        </button>
      )}

      {/* Audio load error */}
      {hasLoadError && !hasPendingTrack && (
        <div className="pointer-events-none absolute bottom-6 left-1/2 z-40 -translate-x-1/2 flex items-center gap-2 rounded-full glass px-4 py-2 text-xs text-rose-50">
          <AlertCircle size={14} />
          Audio unavailable
        </div>
      )}

      {/* Mute indicator when muted */}
      {isMuted && !hasPendingTrack && !hasLoadError && (
        <div className="pointer-events-none absolute bottom-6 left-1/2 z-40 -translate-x-1/2 flex items-center gap-2 rounded-full glass px-4 py-2 text-xs text-cream/50">
          <VolumeX size={14} />
          Sound is muted
        </div>
      )}
    </div>
  );
}
