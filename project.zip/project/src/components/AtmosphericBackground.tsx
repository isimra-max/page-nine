import { useMemo } from 'react';

export function AtmosphericBackground() {
  const bokehOrbs = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => ({
        id: i,
        size: 120 + Math.random() * 220,
        top: `${Math.random() * 100}%`,
        left: `${Math.random() * 100}%`,
        duration: `${18 + Math.random() * 14}s`,
        delay: `${-Math.random() * 20}s`,
        color:
          i % 3 === 0
            ? 'rgba(212,169,90,0.18)'
            : i % 3 === 1
              ? 'rgba(182,124,138,0.14)'
              : 'rgba(245,239,230,0.06)',
      })),
    []
  );

  const particles = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        size: 2 + Math.random() * 4,
        left: `${Math.random() * 100}%`,
        bottom: '-20px',
        duration: `${12 + Math.random() * 18}s`,
        delay: `${-Math.random() * 20}s`,
        drift: `${(Math.random() - 0.5) * 80}px`,
        opacity: 0.3 + Math.random() * 0.4,
      })),
    []
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* Base gradient */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 50% 0%, rgba(212,169,90,0.08), transparent 50%), radial-gradient(ellipse at 30% 100%, rgba(182,124,138,0.07), transparent 55%), linear-gradient(180deg, #0F1115 0%, #121419 50%, #0F1115 100%)',
        }}
      />

      {/* Bokeh orbs */}
      {bokehOrbs.map((o) => (
        <div
          key={o.id}
          className="bokeh-orb"
          style={{
            width: o.size,
            height: o.size,
            top: o.top,
            left: o.left,
            background: o.color,
            animationDuration: o.duration,
            animationDelay: o.delay,
          }}
        />
      ))}

      {/* Floating particles */}
      {particles.map((p) => (
        <span
          key={p.id}
          className="particle"
          style={
            {
              width: p.size,
              height: p.size,
              left: p.left,
              bottom: p.bottom,
              animationDuration: p.duration,
              animationDelay: p.delay,
              '--drift': p.drift,
              '--p-opacity': p.opacity,
            } as React.CSSProperties
          }
        />
      ))}

      {/* Vignette */}
      <div className="absolute inset-0 vignette" />

      {/* Grain */}
      <div className="absolute inset-0 grain" />
    </div>
  );
}
