import { useState, useEffect } from 'react';
import { ArrowLeft, Search, BookOpen, User } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { searchProfiles } from '@/lib/social';
import type { Profile } from '@/lib/supabase';
import { PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface SearchScreenProps {
  onBack: () => void;
  onOpenProfile: (userId: string) => void;
  onOpenBook: (bookId: string, title: string, author: string, cover: string) => void;
}

interface BookResult {
  id: string;
  title: string;
  author: string;
  cover: string;
}

export function SearchScreen({ onBack, onOpenProfile, onOpenBook }: SearchScreenProps) {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState<'books' | 'users'>('books');
  const [bookResults, setBookResults] = useState<BookResult[]>([]);
  const [userResults, setUserResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setBookResults([]);
      setUserResults([]);
      setSearching(false);
      return;
    }

    setSearching(true);
    const timer = setTimeout(async () => {
      if (tab === 'books') {
        try {
          const res = await fetch(
            `https://openlibrary.org/search.json?title=${encodeURIComponent(query)}&limit=12`
          );
          const data = await res.json();
          const results: BookResult[] = (data.docs || [])
            .filter((d: { cover_i?: number }) => d.cover_i)
            .slice(0, 12)
            .map((d: { key: string; title: string; author_name?: string[]; cover_i: number }, i: number) => ({
              id: d.key || `bk-${i}`,
              title: d.title,
              author: d.author_name?.[0] ?? 'Unknown',
              cover: `https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`,
            }));
          setBookResults(results);
        } catch {
          setBookResults([]);
        }
      } else {
        const results = await searchProfiles(query);
        setUserResults(results.filter((p) => p.id !== user?.id));
      }
      setSearching(false);
    }, 400);

    return () => clearTimeout(timer);
  }, [query, tab, user]);

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto bg-charcoal animate-fade-in">
      <div
        className="pointer-events-none fixed inset-0 opacity-30 blur-3xl"
        style={{
          background: 'radial-gradient(circle at 50% 0%, rgba(212,169,90,0.10), transparent 50%)',
        }}
      />

      <div className="relative mx-auto flex min-h-full max-w-2xl flex-col px-6 py-6">
        <div className="mb-4 flex items-center gap-3">
          <button onClick={onBack} className="rounded-full p-1.5 text-cream/60 transition-colors hover:bg-cream/10 hover:text-cream">
            <ArrowLeft size={20} />
          </button>
          <h2 className="font-serif text-lg font-medium text-cream">Search</h2>
        </div>

        {/* Search bar */}
        <div className="mb-4 flex items-center gap-2 rounded-full glass-light px-4 py-3">
          <Search size={16} className="text-cream/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={tab === 'books' ? 'Search books by title...' : 'Search users by name...'}
            className="flex-1 bg-transparent text-sm text-cream placeholder-cream/30 outline-none"
            autoFocus
          />
          {searching && <span className="text-xs text-cream/30">...</span>}
        </div>

        {/* Tab toggle */}
        <div className="mb-5 flex gap-1 rounded-full glass p-1 w-fit">
          <button
            onClick={() => setTab('books')}
            className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-all ${
              tab === 'books' ? 'bg-cream text-charcoal' : 'text-cream/60 hover:text-cream'
            }`}
          >
            <BookOpen size={14} /> Books
          </button>
          <button
            onClick={() => setTab('users')}
            className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-all ${
              tab === 'users' ? 'bg-cream text-charcoal' : 'text-cream/60 hover:text-cream'
            }`}
          >
            <User size={14} /> Users
          </button>
        </div>

        {/* Results */}
        {tab === 'books' ? (
          <div className="flex flex-wrap gap-4">
            {bookResults.map((book) => (
              <button
                key={book.id}
                onClick={() => onOpenBook(book.id, book.title, book.author, book.cover)}
                className="group flex w-24 flex-col items-center"
              >
                <img
                  src={book.cover || PLACEHOLDER_COVER}
                  alt={book.title}
                  onError={(e) => { const img = e.currentTarget; if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER; }}
                  className="h-36 w-24 rounded-lg object-cover ring-1 ring-cream/10 transition-all group-hover:ring-gold/50 group-hover:scale-105"
                />
                <p className="mt-1.5 line-clamp-2 text-center text-[10px] text-cream/50">{book.title}</p>
                <p className="line-clamp-1 text-center text-[9px] text-cream/30">{book.author}</p>
              </button>
            ))}
            {bookResults.length === 0 && query.trim() && !searching && (
              <p className="py-8 text-sm text-cream/30">No books found.</p>
            )}
            {!query.trim() && <p className="py-8 text-sm text-cream/30">Start typing to search for books.</p>}
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {userResults.map((p) => (
              <button
                key={p.id}
                onClick={() => onOpenProfile(p.id)}
                className="flex items-center gap-3 rounded-2xl glass-light p-3 transition-all hover:bg-cream/5"
              >
                <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full glass">
                  {p.avatar_url ? (
                    <img src={p.avatar_url} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-sm font-semibold text-gold">{p.username[0].toUpperCase()}</span>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-cream">{p.display_name || p.username}</p>
                  <p className="text-xs text-cream/40">@{p.username}</p>
                </div>
              </button>
            ))}
            {userResults.length === 0 && query.trim() && !searching && (
              <p className="py-8 text-sm text-cream/30">No users found.</p>
            )}
            {!query.trim() && <p className="py-8 text-sm text-cream/30">Start typing to search for users.</p>}
          </div>
        )}
      </div>
    </div>
  );
}
