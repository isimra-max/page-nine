import { Heart, Bookmark, MessageCircle, Share2, Music, Play, Pause } from 'lucide-react';
import type { Post, Book } from '@/data';
import { StarRating } from './StarRating';
import { useState, useMemo } from 'react';
import { useGoogleBookCover, PLACEHOLDER_COVER } from '@/hooks/useGoogleBookCover';

interface ReelCardProps {
  post: Post;
  book: Book;
  isActive: boolean;
  isPlaying: boolean;
  onOpenBook: (book: Book) => void;
  onToggleLike: (postId: string) => void;
  onToggleSave: (postId: string) => void;
  onOpenComments: (post: Post) => void;
  onTogglePlayPause: () => void;
}

export function ReelCard({
  post,
  book,
  isActive,
  isPlaying,
  onOpenBook,
  onToggleLike,
  onToggleSave,
  onOpenComments,
  onTogglePlayPause,
}: ReelCardProps) {
  const [heartBurst, setHeartBurst] = useState(false);
  const [saveFlip, setSaveFlip] = useState(false);
  const fetched = useGoogleBookCover(book?.title ?? '', book?.coverUrl ?? '');
  const coverUrl = fetched.coverUrl || book?.coverUrl || PLACEHOLDER_COVER;

  const heartParticles = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => ({
        id: i,
        tx: `${(Math.random() - 0.5) * 60}px`,
        ty: `${-20 - Math.random() * 50}px`,
        rot: `${(Math.random() - 0.5) * 60}deg`,
        size: 12 + Math.random() * 8,
      })),
    []
  );

  const handleLike = () => {
    if (!post.liked) {
      setHeartBurst(true);
      setTimeout(() => setHeartBurst(false), 800);
    }
    onToggleLike(post.id);
  };

  const handleSave = () => {
    setSaveFlip(true);
    setTimeout(() => setSaveFlip(false), 500);
    onToggleSave(post.id);
  };

  const handleCoverClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onOpenBook(book);
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(`"${post.text}" — ${book?.title ?? 'Unknown'} by ${book?.author ?? 'Unknown'}, via Page Nine`);
    } catch {
      // ignore
    }
  };

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden rounded-3xl glass border border-cream/8 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.8)]">
      {/* === COVER HERO (top ~40%) === */}
      <button onClick={handleCoverClick} className="group relative h-[40%] w-full shrink-0 overflow-hidden">
        {/* Warm amber glow behind cover */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at 50% 60%, rgba(212,169,90,0.25), transparent 60%), radial-gradient(ellipse at 50% 100%, rgba(182,124,138,0.12), transparent 50%)',
          }}
        />
        {/* Cover image */}
        <img
          src={coverUrl}
          alt={book?.title ?? 'Book cover'}
          onError={(e) => {
            const img = e.currentTarget;
            if (img.src !== PLACEHOLDER_COVER) img.src = PLACEHOLDER_COVER;
          }}
          className="absolute left-1/2 top-1/2 h-[150%] w-auto max-w-none -translate-x-1/2 -translate-y-1/2 object-cover opacity-90 transition-all duration-700 group-hover:scale-105 group-hover:opacity-100"
          style={{ filter: 'saturate(1.05) contrast(1.02)' }}
        />
        {/* Vignette over cover */}
        <div className="absolute inset-0 vignette" />
        {/* Grain over cover */}
        <div className="absolute inset-0 grain" />
        {/* Bottom fade into card */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-charcoal via-charcoal/80 to-transparent" />
        {/* Type badge */}
        <span
          className={`absolute left-4 top-4 rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-widest backdrop-blur-md ${
            post.type === 'quote' ? 'bg-rose/25 text-rose-50' : 'bg-gold/25 text-gold-50'
          }`}
        >
          {post.type}
        </span>
        {/* View book hint */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full glass px-3 py-1 text-[10px] font-medium uppercase tracking-widest text-cream/70 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          View book
        </div>
      </button>

      {/* === CONTENT (bottom ~60%) === */}
      <div className="relative flex flex-1 flex-col gap-3.5 px-6 pb-5 pt-2">
        {/* Quote / review text */}
        <blockquote className="font-serif text-lg leading-relaxed text-cream/95 sm:text-xl">
          {post.text}
        </blockquote>

        {/* Rating for reviews */}
        {post.type === 'review' && post.rating && (
          <div className="flex items-center gap-2">
            <StarRating rating={post.rating} size={16} />
            <span className="text-sm text-cream/50">{post.rating}.0</span>
          </div>
        )}

        {/* Book title / author */}
        <button onClick={handleCoverClick} className="group w-fit">
          <p className="font-serif text-sm font-medium text-cream/70 transition-colors group-hover:text-gold">
            {book?.title ?? 'Unknown'}
          </p>
          <p className="text-xs text-cream/40">by {book?.author ?? 'Unknown'}</p>
        </button>

        {/* Username */}
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-rose to-rose-400 text-[10px] font-bold text-charcoal">
            {post.username[0].toUpperCase()}
          </div>
          <span className="text-sm font-medium text-cream/70">@{post.username}</span>
        </div>

        {/* Music pill with play/pause */}
        {post.audioUrl && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onTogglePlayPause();
          }}
          className="group flex items-center gap-2 rounded-full glass-light px-3 py-1.5 w-fit transition-all hover:bg-cream/8"
        >
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose/30 text-rose-50">
            {isActive && isPlaying ? <Pause size={11} /> : <Play size={11} />}
          </span>
          <Music size={13} className={`text-rose-50 ${isActive && isPlaying ? 'animate-pulse' : ''}`} />
          <span className="text-xs text-cream/60">{post.songTitle}</span>
        </button>
        )}

        {/* Spacer */}
        <div className="flex-1" />

        {/* Action bar */}
        <div className="flex items-center gap-5">
          {/* Like with heart burst */}
          <button onClick={handleLike} className="group relative flex flex-col items-center gap-1">
            <div className="relative">
              <Heart
                size={24}
                className={`transition-all duration-300 ${
                  post.liked
                    ? 'fill-rose text-rose scale-110 drop-shadow-[0_0_8px_rgba(182,124,138,0.6)]'
                    : 'text-cream/70 group-hover:text-rose'
                }`}
              />
              {heartBurst && (
                <>
                  <Heart
                    size={24}
                    className="absolute inset-0 fill-rose text-rose animate-ping"
                    style={{ animationDuration: '0.8s' }}
                  />
                  {heartParticles.map((p) => (
                    <Heart
                      key={p.id}
                      size={p.size}
                      className="heart-particle fill-rose text-rose"
                      style={
                        {
                          '--tx': p.tx,
                          '--ty': p.ty,
                          '--rot': p.rot,
                        } as React.CSSProperties
                      }
                    />
                  ))}
                </>
              )}
            </div>
            <span className="text-xs text-cream/50">{post.likes.toLocaleString()}</span>
          </button>

          {/* Comment */}
          <button onClick={() => onOpenComments(post)} className="group flex flex-col items-center gap-1">
            <MessageCircle
              size={22}
              className="text-cream/70 transition-colors group-hover:text-cream"
            />
            <span className="text-xs text-cream/50">{post.comments.length}</span>
          </button>

          {/* Save with flip */}
          <button onClick={handleSave} className="group flex flex-col items-center gap-1">
            <Bookmark
              size={22}
              className={`transition-all duration-300 ${
                saveFlip ? 'save-flip' : ''
              } ${
                post.saved
                  ? 'fill-gold text-gold scale-110 drop-shadow-[0_0_6px_rgba(212,169,90,0.5)]'
                  : 'text-cream/70 group-hover:text-gold'
              }`}
            />
            <span className="text-xs text-cream/50">{post.saved ? 'Saved' : 'Save'}</span>
          </button>

          {/* Share */}
          <button onClick={handleShare} className="group flex flex-col items-center gap-1">
            <Share2
              size={22}
              className="text-cream/70 transition-colors group-hover:text-cream"
            />
            <span className="text-xs text-cream/50">Share</span>
          </button>
        </div>
      </div>
    </div>
  );
}
